@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  start "" "http://localhost:8000/"
  py -m http.server 8000
  exit /b
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "" "http://localhost:8000/"
  python -m http.server 8000
  exit /b
)
echo Python 3 could not be found.
echo Please install Python 3, then run this file again.
pause

const L={QQVGA:[160,120],QVGA:[320,240],VGA:[640,480],QQQVGA:[80,60],B64X64:[64,64],B128X128:[128,128],LCD:[320,240]};let q=null,R=null,U=L.QVGA,A=null,V=!1,D=!1,Q=0,z=0,E=0,J={},M=[],C={},G=[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],ge=null,W=null;const S=(e,t=0,s=255)=>Math.max(t,Math.min(s,Number(e)||0)),y=(e,t={})=>self.postMessage({type:e,...t}),le=()=>new Date().toLocaleTimeString("ja-JP",{hour12:!1});function p(e){return e==null?e:typeof e.toJs=="function"?e.toJs({dict_converter:Object.fromEntries}):ArrayBuffer.isView(e)?Array.from(e):e}function T(e,t=[255,255,255]){const s=p(e);if(typeof s=="number")return[s,s,s,255].map((r,i)=>i===3?255:S(r));const a=Array.isArray(s)?s:t;return[S(a[0]),S(a[1]),S(a[2]),255]}function oe(e){return{width:e.width,height:e.height,data:new Uint8ClampedArray(e.data)}}function ce(e,t,s){t=Math.max(1,Math.floor(t)),s=Math.max(1,Math.floor(s));const a=new Uint8ClampedArray(t*s*4);for(let r=0;r<s;r++){const i=Math.min(e.height-1,Math.floor(r*e.height/s));for(let n=0;n<t;n++){const l=Math.min(e.width-1,Math.floor(n*e.width/t)),d=(i*e.width+l)*4,f=(r*t+n)*4;a[f]=e.data[d],a[f+1]=e.data[d+1],a[f+2]=e.data[d+2],a[f+3]=255}}return{width:t,height:s,data:a}}function Z(e,t){const[s,a,r,i]=t.map(Number),n=Math.max(0,Math.floor(s)),l=Math.max(0,Math.floor(a)),d=Math.max(1,Math.min(e.width-n,Math.floor(r))),f=Math.max(1,Math.min(e.height-l,Math.floor(i))),g=new Uint8ClampedArray(d*f*4);for(let c=0;c<f;c++){const _=((l+c)*e.width+n)*4;g.set(e.data.subarray(_,_+d*4),c*d*4)}return{width:d,height:f,data:g}}function _e(e){if(!V&&!D)return e;const t=new Uint8ClampedArray(e.data.length);for(let s=0;s<e.height;s++)for(let a=0;a<e.width;a++){const r=V?e.width-1-a:a,i=D?e.height-1-s:s;t.set(e.data.subarray((i*e.width+r)*4,(i*e.width+r)*4+4),(s*e.width+a)*4)}return{width:e.width,height:e.height,data:t}}function pe(e){if(!Q&&!z&&!E)return e;const t=Number(Q)*12,s=1+Number(E)*.12,a=1+Number(z)*.16;for(let r=0;r<e.data.length;r+=4){let i=(e.data[r]-128)*s+128+t,n=(e.data[r+1]-128)*s+128+t,l=(e.data[r+2]-128)*s+128+t;const d=.299*i+.587*n+.114*l;e.data[r]=S(d+(i-d)*a),e.data[r+1]=S(d+(n-d)*a),e.data[r+2]=S(d+(l-d)*a)}return e}function ye(e,t,s){e/=255,t/=255,s/=255,e=e>.04045?((e+.055)/1.055)**2.4:e/12.92,t=t>.04045?((t+.055)/1.055)**2.4:t/12.92,s=s>.04045?((s+.055)/1.055)**2.4:s/12.92;let a=(e*.4124+t*.3576+s*.1805)/.95047,r=e*.2126+t*.7152+s*.0722,i=(e*.0193+t*.1192+s*.9505)/1.08883;const n=l=>l>.008856?Math.cbrt(l):7.787*l+16/116;return a=n(a),r=n(r),i=n(i),[116*r-16,500*(a-r),200*(r-i)]}function he(e,t,s,a){for(const r of a)if(r.length>=6){const[i,n,l]=ye(e,t,s);if(i>=r[0]&&i<=r[1]&&n>=r[2]&&n<=r[3]&&l>=r[4]&&l<=r[5])return!0}else if(r.length>=2){const i=.299*e+.587*t+.114*s;if(i>=r[0]&&i<=r[1])return!0}return!1}function de(e,t,s,a){if(t=Math.round(t),s=Math.round(s),t<0||s<0||t>=e.width||s>=e.height)return;const r=(s*e.width+t)*4;e.data[r]=a[0],e.data[r+1]=a[1],e.data[r+2]=a[2],e.data[r+3]=255}function v(e,t,s,a,r,i,n=1){t=Math.round(t),s=Math.round(s),a=Math.round(a),r=Math.round(r);const l=Math.abs(a-t),d=t<a?1:-1,f=-Math.abs(r-s),g=s<r?1:-1;let c=l+f;for(;;){const _=Math.max(0,Math.floor(n/2));for(let O=-_;O<=_;O++)for(let I=-_;I<=_;I++)de(e,t+I,s+O,i);if(t===a&&s===r)break;const w=2*c;w>=f&&(c+=f,t+=d),w<=l&&(c+=l,s+=g)}}function we(e,t,s,a=1,r=!1){const[i,n,l,d]=t.map(Number);if(r){for(let f=n;f<n+d;f++)for(let g=i;g<i+l;g++)de(e,g,f,s);return}v(e,i,n,i+l,n,s,a),v(e,i,n+d,i+l,n+d,s,a),v(e,i,n,i,n+d,s,a),v(e,i+l,n,i+l,n+d,s,a)}function be(e,t,s,a,r,i=1,n=!1){const l=Number(a),d=n?0:Math.max(0,l-i);for(let f=Math.floor(s-l);f<=Math.ceil(s+l);f++)for(let g=Math.floor(t-l);g<=Math.ceil(t+l);g++){const c=Math.hypot(g-t,f-s);c<=l&&c>=d&&de(e,g,f,r)}}function xe(e,t,s,a,r,i=1){if(typeof OffscreenCanvas>"u")return;const l=new OffscreenCanvas(e.width,e.height).getContext("2d");l.putImageData(new ImageData(e.data,e.width,e.height),0,0),l.fillStyle=`rgb(${r[0]},${r[1]},${r[2]})`,l.font=`${Math.max(10,12*Number(i))}px monospace`,l.textBaseline="top",l.fillText(String(a),Number(t),Number(s)),e.data=l.getImageData(0,0,e.width,e.height).data}function me(e){const t=p(e)||[];return Array.isArray(t)?t.map(s=>Array.from(s,Number)):[]}class ee{constructor(t){this.frame=t,R=t}width(){return this.frame.width}height(){return this.frame.height}size(){return this.frame.data.length}resize(t,s){return this.frame=ce(this.frame,t,s),R=this.frame,this}crop(t){return this.frame=Z(this.frame,Array.from(p(t))),R=this.frame,this}copy(t){return t==null?new ee(oe(this.frame)):new ee(Z(this.frame,Array.from(p(t))))}binary(t,s=!1){const a=me(t);for(let r=0;r<this.frame.data.length;r+=4){let i=he(this.frame.data[r],this.frame.data[r+1],this.frame.data[r+2],a);s&&(i=!i);const n=i?255:0;this.frame.data[r]=n,this.frame.data[r+1]=n,this.frame.data[r+2]=n}return R=this.frame,this}findBlobs(t,s,a=2,r=1,i=!1,n=10,l=10,d=!1,f=0){const g=me(t),c=s==null?[0,0,this.frame.width,this.frame.height]:Array.from(p(s),Number),_=Math.max(0,c[0]|0),w=Math.max(0,c[1]|0),O=Math.min(this.frame.width,_+(c[2]|0)),I=Math.min(this.frame.height,w+(c[3]|0)),b=O-_,B=I-w,te=new Uint8Array(b*B),H=new Uint8Array(b*B);for(let m=0;m<B;m++)for(let u=0;u<b;u++){const o=((m+w)*this.frame.width+u+_)*4;let h=he(this.frame.data[o],this.frame.data[o+1],this.frame.data[o+2],g);i&&(h=!h),te[m*b+u]=h?1:0}const $=[];for(let m=0;m<B;m+=Math.max(1,Number(r)))for(let u=0;u<b;u+=Math.max(1,Number(a))){const o=m*b+u;if(!te[o]||H[o])continue;const h=[u],P=[m];H[o]=1;let F=0,x=0,K=u,se=u,X=m,re=m,fe=0,ue=0;for(;F<h.length;){const N=h[F],k=P[F++];x++,fe+=N,ue+=k,K=Math.min(K,N),se=Math.max(se,N),X=Math.min(X,k),re=Math.max(re,k);for(const[Y,j]of[[N-1,k],[N+1,k],[N,k-1],[N,k+1]]){if(Y<0||j<0||Y>=b||j>=B)continue;const ne=j*b+Y;te[ne]&&!H[ne]&&(H[ne]=1,h.push(Y),P.push(j))}}const ae=se-K+1,ie=re-X+1;x>=Number(l)&&ae*ie>=Number(n)&&$.push({x:K+_,y:X+w,w:ae,h:ie,pixels:x,cx:Math.round(fe/x)+_,cy:Math.round(ue/x)+w,density:x/(ae*ie),rotation:0,code:1})}if(d&&$.length>1){const m=[];for(const u of $.sort((o,h)=>h.pixels-o.pixels)){const o=m.find(h=>u.x<=h.x+h.w+f&&u.x+u.w+f>=h.x&&u.y<=h.y+h.h+f&&u.y+u.h+f>=h.y);if(!o)m.push({...u});else{const h=Math.min(o.x,u.x),P=Math.min(o.y,u.y),F=Math.max(o.x+o.w,u.x+u.w),x=Math.max(o.y+o.h,u.y+u.h);o.pixels+=u.pixels,o.x=h,o.y=P,o.w=F-h,o.h=x-P,o.cx=Math.round(h+o.w/2),o.cy=Math.round(P+o.h/2),o.density=o.pixels/(o.w*o.h)}}return m}return $.sort((m,u)=>u.pixels-m.pixels)}drawRectangle(t,s,a=1,r=!1){return we(this.frame,Array.from(p(t)),T(s),Number(a),!!r),this}drawLine(t,s,a=1){const r=Array.from(p(t));return v(this.frame,r[0],r[1],r[2],r[3],T(s),Number(a)),this}drawCircle(t,s,a,r,i=1,n=!1){return be(this.frame,Number(t),Number(s),Number(a),T(r),Number(i),!!n),this}drawCross(t,s,a,r=5,i=1){const n=T(a);return v(this.frame,t-r,s,t+r,s,n,i),v(this.frame,t,s-r,t,s+r,n,i),this}drawString(t,s,a,r,i=1){return xe(this.frame,t,s,a,T(r),i),this}}function Me(){return{sensorReset:()=>(U=L.QVGA,A=null,V=!1,D=!1,Q=0,z=0,E=0,J={},!0),setFrameSize:e=>{const t=p(e);U=Array.isArray(t)?t.map(Number):L[String(t)]||L.QVGA},setWindowing:e=>{A=Array.from(p(e),Number)},setHMirror:e=>{V=!!e},setVFlip:e=>{D=!!e},setBrightness:e=>{Q=Number(e)||0},setSaturation:e=>{z=Number(e)||0},setContrast:e=>{E=Number(e)||0},readRegister:e=>Number(J[Number(e)]||0),writeRegister:(e,t)=>{J[Number(e)]=Number(t)&255},snapshot:()=>{let e=_e(oe(q));if(U&&(e=ce(e,U[0],U[1])),A?.length===2){const[t,s]=A;e=Z(e,[(e.width-t)/2,(e.height-s)/2,t,s])}else A?.length>=4&&(e=Z(e,A));return e=pe(e),new ee(e)},imageWidth:e=>e.width(),imageHeight:e=>e.height(),imageSize:e=>e.size(),imageResize:(e,t,s)=>e.resize(t,s),imageCrop:(e,t)=>e.crop(t),imageCopy:(e,t)=>e.copy(t),imageBinary:(e,t,s)=>e.binary(t,s),imageFindBlobs:(e,t,s,a,r,i,n,l,d,f)=>e.findBlobs(t,s,a,r,i,n,l,d,f),drawRectangle:(e,t,s,a,r)=>e.drawRectangle(t,s,a,r),drawLine:(e,t,s,a)=>e.drawLine(t,s,a),drawCircle:(e,t,s,a,r,i,n)=>e.drawCircle(t,s,a,r,i,n),drawCross:(e,t,s,a,r,i)=>e.drawCross(t,s,a,r,i),drawString:(e,t,s,a,r,i)=>e.drawString(t,s,a,r,i),log:(...e)=>y("log",{level:"stdout",text:e.map(String).join(" "),time:le()}),uartWrite:e=>{const t=p(e),s=typeof t=="string"?new TextEncoder().encode(t):Uint8Array.from(t);return y("log",{level:"uart",text:new TextDecoder().decode(s),bytes:Array.from(s),time:le()}),s.length},uartAny:()=>M.length,uartRead:e=>{const t=e==null||Number(e)<0?M.length:Math.min(Number(e),M.length);return Uint8Array.from(M.splice(0,t))},uartReadline:()=>{const e=M.indexOf(10),t=e<0?M.length:e+1;return t?Uint8Array.from(M.splice(0,t)):null},gpioGet:e=>Number(C[String(e)]||0),gpioSet:(e,t,s="OUT")=>(C[String(e)]=+!!t,y("gpio",{pin:String(e),value:C[String(e)],mode:String(s)}),C[String(e)]),ledSet:(e,t)=>{const s=Math.max(0,Number(e)|0);for(;G.length<=s;)G.push([0,0,0]);G[s]=T(t).slice(0,3)},ledDisplay:()=>y("led",{colors:G}),kpuAvailable:()=>!1,unsupported:e=>{throw new Error(`未対応のAPIです: ${e}`)}}}const Ne=String.raw`
import sys, types, builtins
from js import bridge

class Blob:
    def __init__(self, d): self._d=d
    def x(self): return int(self._d.x)
    def y(self): return int(self._d.y)
    def w(self): return int(self._d.w)
    def h(self): return int(self._d.h)
    def cx(self): return int(self._d.cx)
    def cy(self): return int(self._d.cy)
    def pixels(self): return int(self._d.pixels)
    def rotation(self): return float(self._d.rotation)
    def code(self): return int(self._d.code)
    def density(self): return float(self._d.density)
    def rect(self): return (self.x(),self.y(),self.w(),self.h())
    def __getitem__(self,i): return (self.x(),self.y(),self.w(),self.h(),self.pixels(),self.cx(),self.cy())[i]
    def __repr__(self): return "Blob(x={}, y={}, w={}, h={}, pixels={})".format(self.x(),self.y(),self.w(),self.h(),self.pixels())

class SimImage:
    def __init__(self, handle=None):
        if handle is None: raise RuntimeError('image.Image(path) は未対応です。sensor.snapshot() を使用してください。')
        self._h=handle
    def width(self): return int(bridge.imageWidth(self._h))
    def height(self): return int(bridge.imageHeight(self._h))
    def size(self): return int(bridge.imageSize(self._h))
    def resize(self,w,h): bridge.imageResize(self._h,w,h); return self
    def crop(self,roi): bridge.imageCrop(self._h,roi); return self
    def copy(self,roi=None): return SimImage(bridge.imageCopy(self._h,roi))
    def binary(self,thresholds,invert=False,**kwargs): bridge.imageBinary(self._h,thresholds,invert); return self
    def find_blobs(self,thresholds,roi=None,x_stride=2,y_stride=1,invert=False,area_threshold=10,pixels_threshold=10,merge=False,margin=0,**kwargs):
        result=bridge.imageFindBlobs(self._h,thresholds,roi,x_stride,y_stride,invert,area_threshold,pixels_threshold,merge,margin)
        return [Blob(x) for x in result]
    def draw_rectangle(self,rect,color=(255,255,255),thickness=1,fill=False,**kwargs): bridge.drawRectangle(self._h,rect,color,thickness,fill); return self
    def draw_line(self,line,color=(255,255,255),thickness=1,**kwargs): bridge.drawLine(self._h,line,color,thickness); return self
    def draw_circle(self,x,y,radius,color=(255,255,255),thickness=1,fill=False,**kwargs): bridge.drawCircle(self._h,x,y,radius,color,thickness,fill); return self
    def draw_cross(self,x,y,color=(255,255,255),size=5,thickness=1,**kwargs): bridge.drawCross(self._h,x,y,color,size,thickness); return self
    def draw_string(self,x,y,text,color=(255,255,255),scale=1,**kwargs): bridge.drawString(self._h,x,y,str(text),color,scale); return self

image=types.ModuleType('image'); image.Image=SimImage; sys.modules['image']=image
sensor=types.ModuleType('sensor')
sensor.RGB565='RGB565'; sensor.GRAYSCALE='GRAYSCALE'; sensor.YUV422='YUV422'
for _name in ['QQVGA','QVGA','VGA','QQQVGA','B64X64','B128X128','LCD']: setattr(sensor,_name,_name)
sensor.reset=lambda *a,**k: bridge.sensorReset()
sensor.set_pixformat=lambda *a,**k: None
sensor.set_framesize=lambda value,*a,**k: bridge.setFrameSize(value)
sensor.set_windowing=lambda value,*a,**k: bridge.setWindowing(value)
sensor.set_hmirror=lambda value=True,*a,**k: bridge.setHMirror(value)
sensor.set_vflip=lambda value=True,*a,**k: bridge.setVFlip(value)
sensor.skip_frames=lambda *a,**k: None
sensor.run=lambda *a,**k: None
sensor.set_auto_gain=lambda *a,**k: None
sensor.set_auto_exposure=lambda *a,**k: None
sensor.set_auto_whitebal=lambda *a,**k: None
sensor.set_brightness=lambda value,*a,**k: bridge.setBrightness(value)
sensor.set_saturation=lambda value,*a,**k: bridge.setSaturation(value)
sensor.set_contrast=lambda value,*a,**k: bridge.setContrast(value)
sensor.__read_reg=lambda address: int(bridge.readRegister(address))
sensor.__write_reg=lambda address,value: bridge.writeRegister(address,value)
sensor.snapshot=lambda: SimImage(bridge.snapshot())
sys.modules['sensor']=sensor

class Clock:
    def __init__(self):
        self._last=_time.time(); self._fps=0
    def tick(self):
        now=_time.time(); delta=now-self._last; self._last=now; self._fps=(1/delta if delta else 0); return delta
    def fps(self): return self._fps
import time as _time
time_mod=types.ModuleType('time')
time_mod.sleep=_time.sleep; time_mod.sleep_ms=lambda ms:_time.sleep(ms/1000); time_mod.ticks_ms=lambda:int(_time.time()*1000); time_mod.clock=Clock
sys.modules['time']=time_mod

class UART:
    UART1=1; UART2=2; UART3=3
    def __init__(self,uart=1,baudrate=115200,*args,**kwargs): self.uart=uart; self.baudrate=baudrate
    def init(self,*args,**kwargs): return None
    def any(self): return int(bridge.uartAny())
    def read(self,n=-1):
        result=bridge.uartRead(n)
        return bytes(result) if result is not None else None
    def readchar(self):
        data=self.read(1); return data[0] if data else -1
    def readline(self):
        result=bridge.uartReadline(); return bytes(result) if result is not None else None
    def write(self,data):
        if isinstance(data,str): data=data.encode('utf-8')
        return int(bridge.uartWrite(list(data)))
    def deinit(self): return None
machine=types.ModuleType('machine'); machine.UART=UART; sys.modules['machine']=machine

class DynamicConstants:
    def __getattr__(self,name): return name
class FM:
    def __init__(self): self.fpioa=DynamicConstants()
    def register(self,*args,**kwargs): return None
    def unregister(self,*args,**kwargs): return None
fm=FM(); fpioa_manager=types.ModuleType('fpioa_manager'); fpioa_manager.fm=fm; sys.modules['fpioa_manager']=fpioa_manager
board=types.ModuleType('board'); board.board_info=DynamicConstants(); sys.modules['board']=board

class GPIO:
    IN=0; OUT=1; PULL_NONE=0; PULL_UP=1; PULL_DOWN=2
    GPIO0='GPIO0'; GPIO1='GPIO1'; GPIO2='GPIO2'; GPIOHS0='GPIOHS0'; GPIOHS1='GPIOHS1'; GPIOHS2='GPIOHS2'
    def __init__(self,pin,mode=OUT,pull=PULL_NONE,value=0,*args,**kwargs):
        self.pin=pin; self.mode=mode
        if mode != self.IN: bridge.gpioSet(str(pin),value,'OUT')
    def value(self,value=None):
        if value is None: return int(bridge.gpioGet(str(self.pin)))
        return int(bridge.gpioSet(str(self.pin),value,'IN' if self.mode==self.IN else 'OUT'))
Maix=types.ModuleType('Maix'); Maix.GPIO=GPIO; sys.modules['Maix']=Maix

class ws2812:
    def __init__(self,pin,led_num=1,*args,**kwargs): self.pin=pin; self.led_num=led_num
    def set_led(self,index,color): bridge.ledSet(index,color)
    def display(self): bridge.ledDisplay()
modules=types.ModuleType('modules'); modules.ws2812=ws2812; sys.modules['modules']=modules

class KPUResult:
    def __init__(self,values): self.values=list(values)
    def __len__(self): return len(self.values)
    def __getitem__(self,i): return self.values[i]
    def tolist(self): return list(self.values)
class Detection:
    def __init__(self,d): self._d=d
    def x(self): return int(self._d.x)
    def y(self): return int(self._d.y)
    def w(self): return int(self._d.w)
    def h(self): return int(self._d.h)
    def value(self): return float(self._d.value)
    def classid(self): return int(self._d.classId)
    def rect(self): return (self.x(),self.y(),self.w(),self.h())
    def __getitem__(self,i): return (self.x(),self.y(),self.w(),self.h(),self.value(),self.classid())[i]
class KPUTask:
    def __init__(self,path): self.path=path
def _require_kpu():
    if not bridge.kpuAvailable(): raise RuntimeError('KPUモデルが読み込まれていません。AIモデル欄でONNXモデルと設定JSONを選択してください。')
kpu=types.ModuleType('KPU')
kpu.load=lambda path,*a,**k: KPUTask(path)
kpu.deinit=lambda task,*a,**k: None
kpu.init_yolo2=lambda *a,**k: _require_kpu()
def _forward(task,img,*args,**kwargs): _require_kpu(); return KPUResult(bridge.kpuValues())
def _run_yolo(task,img,*args,**kwargs): _require_kpu(); return [Detection(d) for d in bridge.kpuDetections()]
kpu.forward=_forward; kpu.run_yolo2=_run_yolo; kpu.softmax=lambda values: KPUResult(values)
sys.modules['KPU']=kpu

_real_print=builtins.print
def sim_print(*args,sep=' ',end='\n',**kwargs): bridge.log(sep.join(str(x) for x in args)+end.rstrip('\n'))
builtins.print=sim_print
`;async function ke(){if(W)return W;y("status",{phase:"loading-python",text:"Python環境を読み込んでいます"});const{loadPyodide:e}=await import(new URL("/pyodide/pyodide.mjs",self.location.href).href);return W=await e({indexURL:new URL("/pyodide/",self.location.href).href}),W}function Ae(e){let t=!1;return{prepared:String(e).replace(/^while\s*\(?\s*True\s*\)?\s*:/gm,()=>(t=!0,"for __unitv_browser_frame in range(1):")),limited:t}}self.onmessage=async e=>{if(e.data?.type!=="run")return;const t=e.data;try{q={width:t.image.width,height:t.image.height,data:new Uint8ClampedArray(t.image.data)},R=oe(q),U=L.QVGA,A=null,V=!1,D=!1,Q=0,z=0,E=0,J={},M=Array.from(new Uint8Array(t.uart||new ArrayBuffer(0))),C={...t.gpio||{}},G=[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],ge=null;const s=await ke();self.bridge=Me(),s.globals.set("bridge",self.bridge),await s.runPythonAsync(Ne);for(const n of t.files||[]){if(!/^[A-Za-z0-9_.-]+\.py$/.test(n.name))continue;s.FS.writeFile(`/${n.name}`,String(n.code||""),{encoding:"utf8"});const l=n.name.replace(/\.py$/,"");await s.runPythonAsync(`import sys
sys.modules.pop(${JSON.stringify(l)}, None)`)}y("status",{phase:"executing",text:"コードを実行しています"});const{prepared:a,limited:r}=Ae(t.code);r&&y("log",{level:"system",text:"固定画像モードのため while(True) を1フレームだけ実行します。",time:le()}),await s.runPythonAsync(a,{filename:t.filename||"main.py"});const i=R||q;y("result",{width:i.width,height:i.height,data:i.data.buffer,gpio:C,leds:G},[i.data.buffer])}catch(s){const a=String(s?.message||s),r=String(s?.stack||"");y("error",{message:a==="PythonError"&&r?r:a,stack:r})}};

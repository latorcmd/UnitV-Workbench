const $={QQVGA:[160,120],QVGA:[320,240],VGA:[640,480],QQQVGA:[80,60],B64X64:[64,64],B128X128:[128,128],LCD:[320,240]};let D=null,w=null,C=$.QVGA,v=null,q=!1,Q=!1,z=0,E=0,H=0,ee={},N=[],O={},R=[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],_e=null,Z=null,k=!1,ye=0;const V=new Map,U=(e,t=0,r=255)=>Math.max(t,Math.min(r,Number(e)||0)),_=(e,t={})=>self.postMessage({type:e,...t}),te=()=>new Date().toLocaleTimeString("ja-JP",{hour12:!1});function we(){if(!k||!w)return;const e=new Uint8ClampedArray(w.data);self.postMessage({type:"frame",width:w.width,height:w.height,data:e.buffer},[e.buffer])}function be(){we();const e=++ye;return _("camera-frame-request",{requestId:e}),new Promise((t,r)=>V.set(e,{resolve:t,reject:r}))}function y(e){return e==null?e:typeof e.toJs=="function"?e.toJs({dict_converter:Object.fromEntries}):ArrayBuffer.isView(e)?Array.from(e):e}function I(e,t=[255,255,255]){const r=y(e);if(typeof r=="number")return[r,r,r,255].map((s,n)=>n===3?255:U(s));const a=Array.isArray(r)?r:t;return[U(a[0]),U(a[1]),U(a[2]),255]}function fe(e){return{width:e.width,height:e.height,data:new Uint8ClampedArray(e.data)}}function pe(e,t,r){t=Math.max(1,Math.floor(t)),r=Math.max(1,Math.floor(r));const a=new Uint8ClampedArray(t*r*4);for(let s=0;s<r;s++){const n=Math.min(e.height-1,Math.floor(s*e.height/r));for(let i=0;i<t;i++){const l=Math.min(e.width-1,Math.floor(i*e.width/t)),d=(n*e.width+l)*4,o=(s*t+i)*4;a[o]=e.data[d],a[o+1]=e.data[d+1],a[o+2]=e.data[d+2],a[o+3]=255}}return{width:t,height:r,data:a}}function re(e,t){const[r,a,s,n]=t.map(Number),i=Math.max(0,Math.floor(r)),l=Math.max(0,Math.floor(a)),d=Math.max(1,Math.min(e.width-i,Math.floor(s))),o=Math.max(1,Math.min(e.height-l,Math.floor(n))),m=new Uint8ClampedArray(d*o*4);for(let c=0;c<o;c++){const g=((l+c)*e.width+i)*4;m.set(e.data.subarray(g,g+d*4),c*d*4)}return{width:d,height:o,data:m}}function xe(e){if(!q&&!Q)return e;const t=new Uint8ClampedArray(e.data.length);for(let r=0;r<e.height;r++)for(let a=0;a<e.width;a++){const s=q?e.width-1-a:a,n=Q?e.height-1-r:r;t.set(e.data.subarray((n*e.width+s)*4,(n*e.width+s)*4+4),(r*e.width+a)*4)}return{width:e.width,height:e.height,data:t}}function Me(e){if(!z&&!E&&!H)return e;const t=Number(z)*12,r=1+Number(H)*.12,a=1+Number(E)*.16;for(let s=0;s<e.data.length;s+=4){let n=(e.data[s]-128)*r+128+t,i=(e.data[s+1]-128)*r+128+t,l=(e.data[s+2]-128)*r+128+t;const d=.299*n+.587*i+.114*l;e.data[s]=U(d+(n-d)*a),e.data[s+1]=U(d+(i-d)*a),e.data[s+2]=U(d+(l-d)*a)}return e}function Ne(e,t,r){e/=255,t/=255,r/=255,e=e>.04045?((e+.055)/1.055)**2.4:e/12.92,t=t>.04045?((t+.055)/1.055)**2.4:t/12.92,r=r>.04045?((r+.055)/1.055)**2.4:r/12.92;let a=(e*.4124+t*.3576+r*.1805)/.95047,s=e*.2126+t*.7152+r*.0722,n=(e*.0193+t*.1192+r*.9505)/1.08883;const i=l=>l>.008856?Math.cbrt(l):7.787*l+16/116;return a=i(a),s=i(s),n=i(n),[116*s-16,500*(a-s),200*(s-n)]}function ce(e,t,r,a){for(const s of a)if(s.length>=6){const[n,i,l]=Ne(e,t,r);if(n>=s[0]&&n<=s[1]&&i>=s[2]&&i<=s[3]&&l>=s[4]&&l<=s[5])return!0}else if(s.length>=2){const n=.299*e+.587*t+.114*r;if(n>=s[0]&&n<=s[1])return!0}return!1}function ue(e,t,r,a){if(t=Math.round(t),r=Math.round(r),t<0||r<0||t>=e.width||r>=e.height)return;const s=(r*e.width+t)*4;e.data[s]=a[0],e.data[s+1]=a[1],e.data[s+2]=a[2],e.data[s+3]=255}function P(e,t,r,a,s,n,i=1){t=Math.round(t),r=Math.round(r),a=Math.round(a),s=Math.round(s);const l=Math.abs(a-t),d=t<a?1:-1,o=-Math.abs(s-r),m=r<s?1:-1;let c=l+o;for(;;){const g=Math.max(0,Math.floor(i/2));for(let G=-g;G<=g;G++)for(let F=-g;F<=g;F++)ue(e,t+F,r+G,n);if(t===a&&r===s)break;const b=2*c;b>=o&&(c+=o,t+=d),b<=l&&(c+=l,r+=m)}}function ke(e,t,r,a=1,s=!1){const[n,i,l,d]=t.map(Number);if(s){for(let o=i;o<i+d;o++)for(let m=n;m<n+l;m++)ue(e,m,o,r);return}P(e,n,i,n+l,i,r,a),P(e,n,i+d,n+l,i+d,r,a),P(e,n,i,n,i+d,r,a),P(e,n+l,i,n+l,i+d,r,a)}function Ae(e,t,r,a,s,n=1,i=!1){const l=Number(a),d=i?0:Math.max(0,l-n);for(let o=Math.floor(r-l);o<=Math.ceil(r+l);o++)for(let m=Math.floor(t-l);m<=Math.ceil(t+l);m++){const c=Math.hypot(m-t,o-r);c<=l&&c>=d&&ue(e,m,o,s)}}function Se(e,t,r,a,s,n=1){if(typeof OffscreenCanvas>"u")return;const l=new OffscreenCanvas(e.width,e.height).getContext("2d");l.putImageData(new ImageData(e.data,e.width,e.height),0,0),l.fillStyle=`rgb(${s[0]},${s[1]},${s[2]})`,l.font=`${Math.max(10,12*Number(n))}px monospace`,l.textBaseline="top",l.fillText(String(a),Number(t),Number(r)),e.data=l.getImageData(0,0,e.width,e.height).data}function ge(e){const t=y(e)||[];return Array.isArray(t)?t.map(r=>Array.from(r,Number)):[]}class se{constructor(t){this.frame=t,w=t}width(){return this.frame.width}height(){return this.frame.height}size(){return this.frame.data.length}resize(t,r){return this.frame=pe(this.frame,t,r),w=this.frame,this}crop(t){return this.frame=re(this.frame,Array.from(y(t))),w=this.frame,this}copy(t){return t==null?new se(fe(this.frame)):new se(re(this.frame,Array.from(y(t))))}binary(t,r=!1){const a=ge(t);for(let s=0;s<this.frame.data.length;s+=4){let n=ce(this.frame.data[s],this.frame.data[s+1],this.frame.data[s+2],a);r&&(n=!n);const i=n?255:0;this.frame.data[s]=i,this.frame.data[s+1]=i,this.frame.data[s+2]=i}return w=this.frame,this}findBlobs(t,r,a=2,s=1,n=!1,i=10,l=10,d=!1,o=0){const m=ge(t),c=r==null?[0,0,this.frame.width,this.frame.height]:Array.from(y(r),Number),g=Math.max(0,c[0]|0),b=Math.max(0,c[1]|0),G=Math.min(this.frame.width,g+(c[2]|0)),F=Math.min(this.frame.height,b+(c[3]|0)),x=G-g,B=F-b,ae=new Uint8Array(x*B),j=new Uint8Array(x*B);for(let p=0;p<B;p++)for(let u=0;u<x;u++){const f=((p+b)*this.frame.width+u+g)*4;let h=ce(this.frame.data[f],this.frame.data[f+1],this.frame.data[f+2],m);n&&(h=!h),ae[p*x+u]=h?1:0}const J=[];for(let p=0;p<B;p+=Math.max(1,Number(s)))for(let u=0;u<x;u+=Math.max(1,Number(a))){const f=p*x+u;if(!ae[f]||j[f])continue;const h=[u],T=[p];j[f]=1;let L=0,M=0,K=u,ne=u,W=p,ie=p,he=0,me=0;for(;L<h.length;){const A=h[L],S=T[L++];M++,he+=A,me+=S,K=Math.min(K,A),ne=Math.max(ne,A),W=Math.min(W,S),ie=Math.max(ie,S);for(const[X,Y]of[[A-1,S],[A+1,S],[A,S-1],[A,S+1]]){if(X<0||Y<0||X>=x||Y>=B)continue;const de=Y*x+X;ae[de]&&!j[de]&&(j[de]=1,h.push(X),T.push(Y))}}const le=ne-K+1,oe=ie-W+1;M>=Number(l)&&le*oe>=Number(i)&&J.push({x:K+g,y:W+b,w:le,h:oe,pixels:M,cx:Math.round(he/M)+g,cy:Math.round(me/M)+b,density:M/(le*oe),rotation:0,code:1})}if(d&&J.length>1){const p=[];for(const u of J.sort((f,h)=>h.pixels-f.pixels)){const f=p.find(h=>u.x<=h.x+h.w+o&&u.x+u.w+o>=h.x&&u.y<=h.y+h.h+o&&u.y+u.h+o>=h.y);if(!f)p.push({...u});else{const h=Math.min(f.x,u.x),T=Math.min(f.y,u.y),L=Math.max(f.x+f.w,u.x+u.w),M=Math.max(f.y+f.h,u.y+u.h);f.pixels+=u.pixels,f.x=h,f.y=T,f.w=L-h,f.h=M-T,f.cx=Math.round(h+f.w/2),f.cy=Math.round(T+f.h/2),f.density=f.pixels/(f.w*f.h)}}return p}return J.sort((p,u)=>u.pixels-p.pixels)}drawRectangle(t,r,a=1,s=!1){return ke(this.frame,Array.from(y(t)),I(r),Number(a),!!s),this}drawLine(t,r,a=1){const s=Array.from(y(t));return P(this.frame,s[0],s[1],s[2],s[3],I(r),Number(a)),this}drawCircle(t,r,a,s,n=1,i=!1){return Ae(this.frame,Number(t),Number(r),Number(a),I(s),Number(n),!!i),this}drawCross(t,r,a,s=5,n=1){const i=I(a);return P(this.frame,t-s,r,t+s,r,i,n),P(this.frame,t,r-s,t,r+s,i,n),this}drawString(t,r,a,s,n=1){return Se(this.frame,t,r,a,I(s),n),this}}function ve(){return{requestCameraFrame:be,sensorReset:()=>(C=$.QVGA,v=null,q=!1,Q=!1,z=0,E=0,H=0,ee={},!0),setFrameSize:e=>{const t=y(e);C=Array.isArray(t)?t.map(Number):$[String(t)]||$.QVGA},setWindowing:e=>{v=Array.from(y(e),Number)},setHMirror:e=>{q=!!e},setVFlip:e=>{Q=!!e},setBrightness:e=>{z=Number(e)||0},setSaturation:e=>{E=Number(e)||0},setContrast:e=>{H=Number(e)||0},readRegister:e=>Number(ee[Number(e)]||0),writeRegister:(e,t)=>{ee[Number(e)]=Number(t)&255},snapshot:()=>{let e=xe(fe(D));if(C&&(e=pe(e,C[0],C[1])),v?.length===2){const[t,r]=v;e=re(e,[(e.width-t)/2,(e.height-r)/2,t,r])}else v?.length>=4&&(e=re(e,v));return e=Me(e),new se(e)},imageWidth:e=>e.width(),imageHeight:e=>e.height(),imageSize:e=>e.size(),imageResize:(e,t,r)=>e.resize(t,r),imageCrop:(e,t)=>e.crop(t),imageCopy:(e,t)=>e.copy(t),imageBinary:(e,t,r)=>e.binary(t,r),imageFindBlobs:(e,t,r,a,s,n,i,l,d,o)=>e.findBlobs(t,r,a,s,n,i,l,d,o),drawRectangle:(e,t,r,a,s)=>e.drawRectangle(t,r,a,s),drawLine:(e,t,r,a)=>e.drawLine(t,r,a),drawCircle:(e,t,r,a,s,n,i)=>e.drawCircle(t,r,a,s,n,i),drawCross:(e,t,r,a,s,n)=>e.drawCross(t,r,a,s,n),drawString:(e,t,r,a,s,n)=>e.drawString(t,r,a,s,n),log:(...e)=>_("log",{level:"stdout",text:e.map(String).join(" "),time:te()}),uartWrite:e=>{const t=y(e),r=typeof t=="string"?new TextEncoder().encode(t):Uint8Array.from(t);return _("log",{level:"uart",text:new TextDecoder().decode(r),bytes:Array.from(r),time:te()}),r.length},uartAny:()=>N.length,uartRead:e=>{const t=e==null||Number(e)<0?N.length:Math.min(Number(e),N.length);return Uint8Array.from(N.splice(0,t))},uartReadline:()=>{const e=N.indexOf(10),t=e<0?N.length:e+1;return t?Uint8Array.from(N.splice(0,t)):null},gpioGet:e=>Number(O[String(e)]||0),gpioSet:(e,t,r="OUT")=>(O[String(e)]=+!!t,_("gpio",{pin:String(e),value:O[String(e)],mode:String(r)}),O[String(e)]),ledSet:(e,t)=>{const r=Math.max(0,Number(e)|0);for(;R.length<=r;)R.push([0,0,0]);R[r]=I(t).slice(0,3)},ledDisplay:()=>_("led",{colors:R}),kpuAvailable:()=>!1,unsupported:e=>{throw new Error(`未対応のAPIです: ${e}`)}}}const Ue=String.raw`
import sys, types, builtins
from js import bridge

class Blob:
    def __init__(self, d): self._d=d
    def x(self): return int(self._d.x)
    def y(self): return int(self._d.y)
    def w(self): return int(self._d.w)
    def h(self): return int(self._d.h)
    def cx(self): return int(self._d.cx)
    def cy(self): return int(self._d.cy)
    def pixels(self): return int(self._d.pixels)
    def rotation(self): return float(self._d.rotation)
    def code(self): return int(self._d.code)
    def density(self): return float(self._d.density)
    def rect(self): return (self.x(),self.y(),self.w(),self.h())
    def __getitem__(self,i): return (self.x(),self.y(),self.w(),self.h(),self.pixels(),self.cx(),self.cy())[i]
    def __repr__(self): return "Blob(x={}, y={}, w={}, h={}, pixels={})".format(self.x(),self.y(),self.w(),self.h(),self.pixels())

class SimImage:
    def __init__(self, handle=None):
        if handle is None: raise RuntimeError('image.Image(path) は未対応です。sensor.snapshot() を使用してください。')
        self._h=handle
    def width(self): return int(bridge.imageWidth(self._h))
    def height(self): return int(bridge.imageHeight(self._h))
    def size(self): return int(bridge.imageSize(self._h))
    def resize(self,w,h): bridge.imageResize(self._h,w,h); return self
    def crop(self,roi): bridge.imageCrop(self._h,roi); return self
    def copy(self,roi=None): return SimImage(bridge.imageCopy(self._h,roi))
    def binary(self,thresholds,invert=False,**kwargs): bridge.imageBinary(self._h,thresholds,invert); return self
    def find_blobs(self,thresholds,roi=None,x_stride=2,y_stride=1,invert=False,area_threshold=10,pixels_threshold=10,merge=False,margin=0,**kwargs):
        result=bridge.imageFindBlobs(self._h,thresholds,roi,x_stride,y_stride,invert,area_threshold,pixels_threshold,merge,margin)
        return [Blob(x) for x in result]
    def draw_rectangle(self,rect,color=(255,255,255),thickness=1,fill=False,**kwargs): bridge.drawRectangle(self._h,rect,color,thickness,fill); return self
    def draw_line(self,line,color=(255,255,255),thickness=1,**kwargs): bridge.drawLine(self._h,line,color,thickness); return self
    def draw_circle(self,x,y,radius,color=(255,255,255),thickness=1,fill=False,**kwargs): bridge.drawCircle(self._h,x,y,radius,color,thickness,fill); return self
    def draw_cross(self,x,y,color=(255,255,255),size=5,thickness=1,**kwargs): bridge.drawCross(self._h,x,y,color,size,thickness); return self
    def draw_string(self,x,y,text,color=(255,255,255),scale=1,**kwargs): bridge.drawString(self._h,x,y,str(text),color,scale); return self

image=types.ModuleType('image'); image.Image=SimImage; sys.modules['image']=image
sensor=types.ModuleType('sensor')
sensor.RGB565='RGB565'; sensor.GRAYSCALE='GRAYSCALE'; sensor.YUV422='YUV422'
for _name in ['QQVGA','QVGA','VGA','QQQVGA','B64X64','B128X128','LCD']: setattr(sensor,_name,_name)
sensor.reset=lambda *a,**k: bridge.sensorReset()
sensor.set_pixformat=lambda *a,**k: None
sensor.set_framesize=lambda value,*a,**k: bridge.setFrameSize(value)
sensor.set_windowing=lambda value,*a,**k: bridge.setWindowing(value)
sensor.set_hmirror=lambda value=True,*a,**k: bridge.setHMirror(value)
sensor.set_vflip=lambda value=True,*a,**k: bridge.setVFlip(value)
sensor.skip_frames=lambda *a,**k: None
sensor.run=lambda *a,**k: None
sensor.set_auto_gain=lambda *a,**k: None
sensor.set_auto_exposure=lambda *a,**k: None
sensor.set_auto_whitebal=lambda *a,**k: None
sensor.set_brightness=lambda value,*a,**k: bridge.setBrightness(value)
sensor.set_saturation=lambda value,*a,**k: bridge.setSaturation(value)
sensor.set_contrast=lambda value,*a,**k: bridge.setContrast(value)
sensor.__read_reg=lambda address: int(bridge.readRegister(address))
sensor.__write_reg=lambda address,value: bridge.writeRegister(address,value)
sensor.snapshot=lambda: SimImage(bridge.snapshot())
async def _snapshot_async():
    await bridge.requestCameraFrame()
    return sensor.snapshot()
sensor.snapshot_async=_snapshot_async
sys.modules['sensor']=sensor

class Clock:
    def __init__(self):
        self._last=_time.time(); self._fps=0
    def tick(self):
        now=_time.time(); delta=now-self._last; self._last=now; self._fps=(1/delta if delta else 0); return delta
    def fps(self): return self._fps
import time as _time
time_mod=types.ModuleType('time')
time_mod.sleep=_time.sleep; time_mod.sleep_ms=lambda ms:_time.sleep(ms/1000); time_mod.ticks_ms=lambda:int(_time.time()*1000); time_mod.clock=Clock
sys.modules['time']=time_mod

class UART:
    UART1=1; UART2=2; UART3=3
    def __init__(self,uart=1,baudrate=115200,*args,**kwargs): self.uart=uart; self.baudrate=baudrate
    def init(self,*args,**kwargs): return None
    def any(self): return int(bridge.uartAny())
    def read(self,n=-1):
        result=bridge.uartRead(n)
        return bytes(result) if result is not None else None
    def readchar(self):
        data=self.read(1); return data[0] if data else -1
    def readline(self):
        result=bridge.uartReadline(); return bytes(result) if result is not None else None
    def write(self,data):
        if isinstance(data,str): data=data.encode('utf-8')
        return int(bridge.uartWrite(list(data)))
    def deinit(self): return None
machine=types.ModuleType('machine'); machine.UART=UART; sys.modules['machine']=machine

class DynamicConstants:
    def __getattr__(self,name): return name
class FM:
    def __init__(self): self.fpioa=DynamicConstants()
    def register(self,*args,**kwargs): return None
    def unregister(self,*args,**kwargs): return None
fm=FM(); fpioa_manager=types.ModuleType('fpioa_manager'); fpioa_manager.fm=fm; sys.modules['fpioa_manager']=fpioa_manager
board=types.ModuleType('board'); board.board_info=DynamicConstants(); sys.modules['board']=board

class GPIO:
    IN=0; OUT=1; PULL_NONE=0; PULL_UP=1; PULL_DOWN=2
    GPIO0='GPIO0'; GPIO1='GPIO1'; GPIO2='GPIO2'; GPIOHS0='GPIOHS0'; GPIOHS1='GPIOHS1'; GPIOHS2='GPIOHS2'
    def __init__(self,pin,mode=OUT,pull=PULL_NONE,value=0,*args,**kwargs):
        self.pin=pin; self.mode=mode
        if mode != self.IN: bridge.gpioSet(str(pin),value,'OUT')
    def value(self,value=None):
        if value is None: return int(bridge.gpioGet(str(self.pin)))
        return int(bridge.gpioSet(str(self.pin),value,'IN' if self.mode==self.IN else 'OUT'))
Maix=types.ModuleType('Maix'); Maix.GPIO=GPIO; sys.modules['Maix']=Maix

class ws2812:
    def __init__(self,pin,led_num=1,*args,**kwargs): self.pin=pin; self.led_num=led_num
    def set_led(self,index,color): bridge.ledSet(index,color)
    def display(self): bridge.ledDisplay()
modules=types.ModuleType('modules'); modules.ws2812=ws2812; sys.modules['modules']=modules

class KPUResult:
    def __init__(self,values): self.values=list(values)
    def __len__(self): return len(self.values)
    def __getitem__(self,i): return self.values[i]
    def tolist(self): return list(self.values)
class Detection:
    def __init__(self,d): self._d=d
    def x(self): return int(self._d.x)
    def y(self): return int(self._d.y)
    def w(self): return int(self._d.w)
    def h(self): return int(self._d.h)
    def value(self): return float(self._d.value)
    def classid(self): return int(self._d.classId)
    def rect(self): return (self.x(),self.y(),self.w(),self.h())
    def __getitem__(self,i): return (self.x(),self.y(),self.w(),self.h(),self.value(),self.classid())[i]
class KPUTask:
    def __init__(self,path): self.path=path
def _require_kpu():
    if not bridge.kpuAvailable(): raise RuntimeError('KPUモデルが読み込まれていません。AIモデル欄でONNXモデルと設定JSONを選択してください。')
kpu=types.ModuleType('KPU')
kpu.load=lambda path,*a,**k: KPUTask(path)
kpu.deinit=lambda task,*a,**k: None
kpu.init_yolo2=lambda *a,**k: _require_kpu()
def _forward(task,img,*args,**kwargs): _require_kpu(); return KPUResult(bridge.kpuValues())
def _run_yolo(task,img,*args,**kwargs): _require_kpu(); return [Detection(d) for d in bridge.kpuDetections()]
kpu.forward=_forward; kpu.run_yolo2=_run_yolo; kpu.softmax=lambda values: KPUResult(values)
sys.modules['KPU']=kpu

_real_print=builtins.print
def sim_print(*args,sep=' ',end='\n',**kwargs): bridge.log(sep.join(str(x) for x in args)+end.rstrip('\n'))
builtins.print=sim_print
`;async function Pe(){if(Z)return Z;_("status",{phase:"loading-python",text:"Python環境を読み込んでいます"});const{loadPyodide:e}=await import(new URL("/pyodide/pyodide.mjs",self.location.href).href);return Z=await e({indexURL:new URL("/pyodide/",self.location.href).href}),Z}function Te(e,t=!1){if(t)return{prepared:String(e).replace(/\bsensor\s*\.\s*snapshot\s*\(\s*\)/g,"await sensor.snapshot_async()"),limited:!1};let r=!1;return{prepared:String(e).replace(/^while\s*\(?\s*True\s*\)?\s*:/gm,()=>(r=!0,"for __unitv_browser_frame in range(1):")),limited:r}}self.onmessage=async e=>{const t=e.data;if(t?.type==="camera-frame"){const r=V.get(t.requestId);if(!r)return;V.delete(t.requestId),D={width:t.image.width,height:t.image.height,data:new Uint8ClampedArray(t.image.data)},r.resolve(!0);return}if(t?.type==="camera-frame-error"){const r=V.get(t.requestId);if(!r)return;V.delete(t.requestId),r.reject(new Error(t.message||"カメラフレームを取得できませんでした。"));return}if(t?.type==="run")try{k=!!t.cameraMode,D={width:t.image.width,height:t.image.height,data:new Uint8ClampedArray(t.image.data)},w=fe(D),C=$.QVGA,v=null,q=!1,Q=!1,z=0,E=0,H=0,ee={},N=Array.from(new Uint8Array(t.uart||new ArrayBuffer(0))),O={...t.gpio||{}},R=[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],_e=null;const r=await Pe();self.bridge=ve(),r.globals.set("bridge",self.bridge),await r.runPythonAsync(Ue);const a=`/unitv-project-${crypto.randomUUID()}`;r.FS.mkdirTree(a);for(const d of t.files||[]){const o=String(d.name||"").replace(/\\/g,"/").replace(/^\/+/,"");if(!o.endsWith(".py")||o.split("/").some(g=>!g||g==="."||g===".."))continue;const m=o.includes("/")?o.slice(0,o.lastIndexOf("/")):"";m&&r.FS.mkdirTree(`${a}/${m}`),r.FS.writeFile(`${a}/${o}`,String(d.code||""),{encoding:"utf8"});const c=o.replace(/\.py$/,"").replace(/\//g,".").replace(/\.__init__$/,"");await r.runPythonAsync(`import sys
sys.modules.pop(${JSON.stringify(c)}, None)`)}const s=String(t.filename||"").replace(/\\/g,"/").includes("/")?String(t.filename).replace(/\\/g,"/").slice(0,String(t.filename).replace(/\\/g,"/").lastIndexOf("/")):"";await r.runPythonAsync(`import os, sys, importlib
os.chdir(${JSON.stringify(a)})
sys.path.insert(0, ${JSON.stringify(a)})
sys.path.insert(0, ${JSON.stringify(`${a}/${s}`)})
importlib.invalidate_caches()`),_("status",{phase:"executing",text:k?"カメラフレームを連続処理しています":"コードを実行しています",liveCamera:k});const{prepared:n,limited:i}=Te(t.code,k);i&&_("log",{level:"system",text:"固定画像モードのため while(True) を1フレームだけ実行します。",time:te()}),k&&_("log",{level:"system",text:"カメラモード: while(True) を維持し、sensor.snapshot() ごとに新しいフレームを取得します。停止ボタンで終了できます。",time:te()}),await r.runPythonAsync(n,{filename:t.filename||"main.py"});const l=w||D;k=!1,_("result",{width:l.width,height:l.height,data:l.data.buffer,gpio:O,leds:R},[l.data.buffer])}catch(r){k=!1;const a=String(r?.message||r),s=String(r?.stack||"");_("error",{message:a==="PythonError"&&s?s:a,stack:s})}};

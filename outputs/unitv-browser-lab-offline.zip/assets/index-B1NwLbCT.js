(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))a(o);new MutationObserver(o=>{for(const d of o)if(d.type==="childList")for(const y of d.addedNodes)y.tagName==="LINK"&&y.rel==="modulepreload"&&a(y)}).observe(document,{childList:!0,subtree:!0});function n(o){const d={};return o.integrity&&(d.integrity=o.integrity),o.referrerPolicy&&(d.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?d.credentials="include":o.crossOrigin==="anonymous"?d.credentials="omit":d.credentials="same-origin",d}function a(o){if(o.ep)return;o.ep=!0;const d=n(o);fetch(o.href,d)}})();const k=15*1024*1024,T=8e3,_={color:`import sensor
import image
import time

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)

img = sensor.snapshot()
threshold = [(20, 85, 15, 95, 5, 85)]
blobs = img.find_blobs(threshold, pixels_threshold=80, area_threshold=80)

for blob in blobs:
    img.draw_rectangle(blob.rect(), color=(255, 174, 66), thickness=3)
    img.draw_cross(blob.cx(), blob.cy(), color=(255, 255, 255), size=7)
    print("blob:", blob.cx(), blob.cy(), blob.pixels())

print("detected:", len(blobs))`,uart:`from machine import UART
from board import board_info
from fpioa_manager import fm

fm.register(board_info.CONNEXT_A, fm.fpioa.UART1_TX)
fm.register(board_info.CONNEXT_B, fm.fpioa.UART1_RX)
uart = UART(UART.UART1, 115200)

print("UART bytes:", uart.any())
data = uart.readline()
if data:
    print("RX:", data.decode("utf-8"))
    uart.write("echo: ")
    uart.write(data)`,io:`from Maix import GPIO
from modules import ws2812
from board import board_info
import sensor

sensor.reset()
img = sensor.snapshot()

button = GPIO(GPIO.GPIOHS0, GPIO.IN, GPIO.PULL_UP)
led_pin = GPIO(GPIO.GPIO0, GPIO.OUT)
led_pin.value(button.value())

leds = ws2812(board_info.CONNEXT_A, 4)
leds.set_led(0, (49, 227, 212))
leds.set_led(1, (255, 174, 66))
leds.set_led(2, (99, 174, 250))
leds.set_led(3, (255, 107, 107))
leds.display()
print("GPIOHS0:", button.value())`,unitv:`from machine import UART
from board import board_info
from fpioa_manager import fm
from Maix import GPIO
from modules import ws2812
import sensor
import image
import time

fm.register(35, fm.fpioa.UART1_TX, force=True)
fm.register(34, fm.fpioa.UART1_RX, force=True)
fm.register(18, fm.fpioa.GPIO1)
ButtonA = GPIO(GPIO.GPIO1, GPIO.IN, GPIO.PULL_UP)
fm.register(19, fm.fpioa.GPIO2)
ButtonB = GPIO(GPIO.GPIO2, GPIO.IN, GPIO.PULL_UP)

thresholds = ((11, 54, -4, 56, -86, -13),
              (33, 58, -62, -21, -7, 53),
              (70, 88, -19, 32, 67, 88),
              (45, 55, 60, 82, 51, 77),
              (4, 15, -28, 37, 5, 22))
point = (2, 1, 0, -1, -2)

sensor.reset()
sensor.set_hmirror(1)
sensor.set_vflip(1)
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
com13 = sensor.__read_reg(0x13)
com13 &= ~(1 << 2)
com13 &= ~(1 << 0)
sensor.__write_reg(0x13, com13)
manual_gain = 0x200
sensor.__write_reg(0x00, manual_gain & 0xFF)
reg15 = sensor.__read_reg(0x15)
reg15 &= ~0x03
reg15 |= (manual_gain >> 8) & 0x03
sensor.__write_reg(0x15, reg15)
sensor.set_auto_gain(False, gain_db=20)
sensor.set_auto_exposure(False, exposure_us=10000)
sensor.set_auto_whitebal(False, rgb_gain_db=(40, 35, 65))
sensor.set_brightness(3)
sensor.set_saturation(3)
sensor.set_contrast(3)
sensor.set_windowing((224, 224))
sensor.skip_frames(time=2000)
sensor.snapshot()

class_ws2812 = ws2812(8, 1)
class_ws2812.set_led(0, (0, 0, 0))
class_ws2812.display()

while(True):
    img = sensor.snapshot()
    blobs = [img.find_blobs([thresholds[0]], merge=True, margin=20, pixels_threshold=100),
             img.find_blobs([thresholds[1]], merge=True, margin=20, pixels_threshold=100),
             img.find_blobs([thresholds[2]], merge=True, margin=20, pixels_threshold=100),
             img.find_blobs([thresholds[3]], merge=True, margin=20, pixels_threshold=100),
             img.find_blobs([thresholds[4]], merge=True, margin=20, pixels_threshold=100)]
    lst = []
    total = 3
    if any(blobs):
        print(blobs)
        for i in range(5):
            for blob in blobs[i]:
                lst.append([blob.x(), blob.y(), blob.x()+blob.w(), blob.y()+blob.h(), blob.h()*blob.w(), blob.cx(), blob.cy(), point[i]])
        lst_len = len(lst)
        if lst_len == 1 and lst[0][7] == 0 and lst[0][4] > 5000:
            total = 0
        elif lst_len >= 2:
            for i in range(5, 7):
                lst = sorted(lst, key=lambda x:x[i])
                mode = lst[(lst_len - 1) // 2][i]
                lst = [j for j in lst if mode - 50 < j[i] < mode + 50]
                lst_len = len(lst)
            if lst_len == 1 and lst[0][7] == 0 and lst[0][4] > 5000:
                total = 0
            elif 2 <= lst_len <= 4:
                lst = sorted(lst, key=lambda x:x[1])
                width = [[lst[i+1][1] - lst[i][1], lst[i][7]] for i in range(lst_len - 1)]
                width.append([lst[lst_len - 1][6] - lst[-1][1], lst[-1][7]])
                width = sorted(width, key=lambda x:x[0])
                minw = width[0][0]
                if minw != 0:
                    width = [[width[i][0] / minw, width[i][1]] for i in range(lst_len)]
                    total = 3
            elif lst_len == 5:
                total = sum(i[7] for i in lst)
    print(total)`};document.querySelector("#app").innerHTML=`
  <main class="app-shell">
    <header class="topbar">
      <div class="brand">
        <span class="brand-mark" aria-hidden="true"><i></i><i></i></span>
        <div><h1>UnitV Browser Lab</h1><p>MaixPyを、ブラウザで試す。</p></div>
      </div>
      <div class="top-actions">
        <span class="privacy-pill"><span></span>画像・コードは端末内で処理</span>
        <button class="ghost-button" id="api-open" type="button">API一覧</button>
        <button class="ghost-button" id="project-open" type="button">プロジェクトを開く</button>
        <button class="ghost-button" id="project-save" type="button">保存</button>
        <a class="ghost-button download-link" href="/unitv-browser-lab-offline.zip" download>オフライン版</a>
        <input id="project-file" class="visually-hidden" type="file" accept="application/json,.unitvproj" />
      </div>
    </header>

    <section class="control-strip" aria-label="実行コントロール">
      <label class="upload-card" for="image-file" tabindex="0">
        <span class="step">01</span><span><strong id="image-label">入力画像</strong><small id="image-detail">PNG / JPG / WebP・最大15 MB</small></span>
        <span class="upload-action">画像を選ぶ</span>
        <input id="image-file" type="file" accept="image/png,image/jpeg,image/webp" />
      </label>
      <button class="sample-image-button" id="sample-image" type="button">サンプル画像</button>
      <div class="control-divider"></div>
      <div class="run-copy"><span class="step">02</span><span><strong>コードを実行</strong><small>実行上限 8秒</small></span></div>
      <button class="run-button" id="run" type="button"><span>▶</span> 実行</button>
      <button class="stop-button" id="stop" type="button" disabled>■ 停止</button>
      <div class="runtime-state" id="runtime-state"><span></span><div><strong>準備完了</strong><small>画像を選択してください</small></div></div>
    </section>

    <section class="workspace">
      <article class="panel code-panel">
        <div class="panel-head">
          <div><span class="panel-kicker">EDITOR</span><h2>main.py</h2></div>
          <div class="panel-tools">
            <label class="select-label" for="sample-select">サンプル</label>
            <select id="sample-select" aria-label="サンプルコード">
              <option value="color">色ブロブ検出</option>
              <option value="uart">UART送受信</option>
              <option value="io">GPIO・WS2812</option>
              <option value="unitv">カラー判定（実機コード）</option>
            </select>
            <span>Python / MaixPy</span>
          </div>
        </div>
        <div class="editor-wrap">
          <pre class="line-numbers" id="line-numbers" aria-hidden="true"></pre>
          <textarea id="code-editor" aria-label="Pythonコードエディター" spellcheck="false"></textarea>
        </div>
      </article>

      <div class="right-stack">
        <article class="panel output-panel">
          <div class="panel-head">
            <div><span class="panel-kicker amber">FRAME BUFFER</span><h2>画像出力</h2></div>
            <div class="panel-tools"><button id="download-image" type="button" disabled>PNG保存</button><span class="meta" id="frame-meta">—</span></div>
          </div>
          <div class="canvas-stage" id="canvas-stage">
            <canvas id="output-canvas" hidden></canvas>
            <div class="empty-frame" id="empty-frame">
              <span class="image-glyph">▧</span><strong>画像を選んでください</strong><small>アップロード画像が仮想カメラになります</small>
            </div>
          </div>
        </article>

        <article class="panel serial-panel">
          <div class="panel-head">
            <div><span class="panel-kicker blue">SERIAL MONITOR</span><h2>シリアルモニタ</h2></div>
            <div class="panel-tools"><button id="clear-log" type="button">消去</button><span>115200 baud</span></div>
          </div>
          <div class="terminal" id="terminal" role="log" aria-live="polite"></div>
        </article>
      </div>
    </section>

    <section class="io-dock panel">
      <div class="io-header">
        <div class="io-title"><span class="panel-kicker">DEVICE BAY</span><h2>仮想デバイス</h2></div>
        <span class="device-note">GPIO1 / GPIO2は実機のButton A / Bに対応</span>
      </div>
      <div class="device-pane active" id="io-pane" role="tabpanel">
        <div class="uart-field"><label for="uart-input">UART RX</label><input id="uart-input" value="hello UnitV\\n" /><select id="uart-format" aria-label="UART入力形式"><option value="text">TEXT</option><option value="hex">HEX</option></select><button id="uart-queue" type="button">受信キューへ</button></div>
        <div class="gpio-bank"><span>GPIO INPUT</span>${["GPIO1","GPIO2","GPIOHS0"].map(t=>`<button type="button" data-gpio="${t}" aria-pressed="false"><small>${t}</small><b>LOW</b></button>`).join("")}</div>
        <div class="led-bank"><span>WS2812</span>${[0,1,2,3].map(t=>`<i data-led="${t}" title="LED ${t}"></i>`).join("")}</div>
      </div>
    </section>
  </main>

  <dialog id="api-dialog" class="dialog">
    <form method="dialog"><div class="dialog-head"><div><span class="panel-kicker">COMPATIBILITY</span><h2>対応API</h2></div><button value="close" aria-label="閉じる">×</button></div>
      <div class="api-grid">
        <section><h3>sensor</h3><p>reset / set_pixformat / set_framesize / set_hmirror / set_vflip / skip_frames / snapshot</p></section>
        <section><h3>image</h3><p>resize / crop / copy / binary / find_blobs / draw_rectangle / draw_line / draw_circle / draw_cross / draw_string</p></section>
        <section><h3>UART・I/O</h3><p>UART read / readline / readchar / write / any、GPIO value、ws2812 set_led / display</p></section>
        <section><h3>カメラ設定</h3><p>レジスタ読書き、auto gain / exposure / white balance、brightness / saturation / contrast、windowing</p></section>
      </div><p class="dialog-note">固定画像モードではトップレベルの while(True) を1フレームだけ実行します。KPUは未対応です。</p>
    </form>
  </dialog>

  <dialog id="save-dialog" class="dialog small-dialog">
    <form method="dialog"><div class="dialog-head"><div><span class="panel-kicker">PROJECT FILE</span><h2>プロジェクトを保存</h2></div><button value="close" aria-label="閉じる">×</button></div>
      <label class="check-row"><input id="embed-image" type="checkbox" checked><span><strong>入力画像を含める</strong><small>別の端末でも同じ状態から再開できます</small></span></label>
      <div class="dialog-actions"><button value="close" class="ghost-button">キャンセル</button><button type="button" class="run-button" id="confirm-save">ダウンロード</button></div>
    </form>
  </dialog>
`;const i=t=>document.querySelector(t),s={code:i("#code-editor"),lines:i("#line-numbers"),imageFile:i("#image-file"),canvas:i("#output-canvas"),empty:i("#empty-frame"),imageLabel:i("#image-label"),imageDetail:i("#image-detail"),frameMeta:i("#frame-meta"),terminal:i("#terminal"),run:i("#run"),stop:i("#stop"),runtime:i("#runtime-state"),uart:i("#uart-input"),uartFormat:i("#uart-format")};let r=null,b=null,h="",c=null,u=null,x=!1,p={GPIO1:0,GPIO2:0,GPIOHS0:0},w=new Uint8Array;s.code.value=_.color;f();l("system","画像を選択し、コードを確認して「実行」を押してください。");function f(){s.lines.textContent=Array.from({length:s.code.value.split(`
`).length},(t,e)=>e+1).join(`
`)}function l(t,e,n=new Date().toLocaleTimeString("ja-JP",{hour12:!1})){const a=document.createElement("div");a.className=`log-line ${t}`;const o=String(e).replace(/\n$/,"");a.innerHTML=`<span class="time">${n}</span><span class="log-tag">[${t}]</span><span class="log-text"></span>`,a.querySelector(".log-text").textContent=o||" ",s.terminal.append(a),s.terminal.scrollTop=s.terminal.scrollHeight}function m(t,e,n=""){s.runtime.className=`runtime-state ${n}`,s.runtime.querySelector("strong").textContent=t,s.runtime.querySelector("small").textContent=e}function v(t){x=t,s.run.disabled=t,s.stop.disabled=!t,s.run.innerHTML=t?'<span class="spinner"></span> 実行中':"<span>▶</span> 実行"}function L(t,e){const n=URL.createObjectURL(t),a=document.createElement("a");a.href=n,a.download=e,a.click(),setTimeout(()=>URL.revokeObjectURL(n),1e3)}async function A(t){return await new Promise((e,n)=>{const a=new FileReader;a.onload=()=>e(a.result),a.onerror=n,a.readAsDataURL(t)})}async function R(t,e="project-image.png"){const a=await(await fetch(t)).blob();return E(new File([a],e,{type:a.type||"image/png"}),t)}async function E(t,e=null){if(!t)return;if(!["image/png","image/jpeg","image/webp"].includes(t.type))throw new Error("PNG、JPG、WebPの画像を選択してください。");if(t.size>k)throw new Error("画像は15 MB以下にしてください。");const n=await createImageBitmap(t);if(n.width*n.height>2e7)throw n.close(),new Error("画像の画素数が大きすぎます。最大20メガピクセルです。");const a=document.createElement("canvas");a.width=n.width,a.height=n.height;const o=a.getContext("2d",{willReadFrequently:!0});o.drawImage(n,0,0),n.close(),r=o.getImageData(0,0,a.width,a.height),b=e||await A(t),h=t.name,P(r),s.imageLabel.textContent=t.name,s.imageDetail.textContent=`${r.width} × ${r.height}・${(t.size/1024/1024).toFixed(1)} MB`,m("準備完了","コードを実行できます"),l("system",`画像を読み込みました: ${t.name} (${r.width} × ${r.height})`)}function S(){const t=document.createElement("canvas");t.width=640,t.height=480;const e=t.getContext("2d"),n=e.createLinearGradient(0,0,640,480);n.addColorStop(0,"#162b38"),n.addColorStop(1,"#071017"),e.fillStyle=n,e.fillRect(0,0,640,480),e.fillStyle="#ffae42",e.beginPath(),e.arc(190,230,92,0,Math.PI*2),e.fill(),e.fillStyle="#31e3d4",e.fillRect(350,130,170,190),e.fillStyle="#63aefa",e.beginPath(),e.moveTo(230,390),e.lineTo(320,285),e.lineTo(410,390),e.closePath(),e.fill(),e.fillStyle="#ffffff",e.font="bold 30px sans-serif",e.fillText("UnitV sample",210,62),r=e.getImageData(0,0,640,480),b=t.toDataURL("image/png"),h="unitv-sample.png",P(r),s.imageLabel.textContent=h,s.imageDetail.textContent="640 × 480・組み込みサンプル",m("準備完了","コードを実行できます"),l("system","サンプル画像を読み込みました。")}function P(t){s.canvas.width=t.width,s.canvas.height=t.height,s.canvas.getContext("2d").putImageData(t,0,0),s.canvas.hidden=!1,s.empty.hidden=!0,s.frameMeta.textContent=`${t.width} × ${t.height}`,i("#download-image").disabled=!1}function $(){const t=s.uart.value.replace(/\\n/g,`
`).replace(/\\r/g,"\r");if(s.uartFormat.value==="hex"){const e=t.trim();if(!e)return new Uint8Array;const n=e.split(/[\s,]+/);if(n.some(a=>!/^[0-9a-f]{1,2}$/i.test(a)))throw new Error("HEX入力は「48 65 6C 6C 6F」のように入力してください。");return Uint8Array.from(n.map(a=>parseInt(a,16)))}return new TextEncoder().encode(t)}function j(){return c||(c=new Worker(new URL("/assets/simulator.worker-B3i_PAGL.js",import.meta.url),{type:"module"}),c.onmessage=C,c.onerror=t=>g(`実行環境を開始できませんでした: ${t.message}`),c)}function C(t){const e=t.data;if(e.type==="status"){const a={"loading-python":["Pythonを準備中",e.text],"loading-model":["モデルを準備中",e.text],executing:["実行中",`最大${T/1e3}秒で停止します`]}[e.phase]||["処理中",e.text||""];m(a[0],a[1],"busy"),e.phase==="executing"&&(clearTimeout(u),u=setTimeout(()=>G("実行時間が8秒を超えたため停止しました。"),T))}else e.type==="log"?l(e.level||"stdout",e.text,e.time):e.type==="gpio"?(p[e.pin]=Number(e.value),I(e.pin,e.value,e.mode)):e.type==="led"?O(e.colors):e.type==="result"?(clearTimeout(u),u=null,P(new ImageData(new Uint8ClampedArray(e.data),e.width,e.height)),e.gpio&&Object.assign(p,e.gpio),e.leds&&O(e.leds),v(!1),m("実行完了",`${e.width} × ${e.height} の画像を出力しました`,"success"),l("system","実行が完了しました。")):e.type==="error"&&g(N(e.message))}function N(t){return String(t).replace("PythonError: ","").replace(/File "main.py", line (\d+)/g,"main.py:$1")}function g(t){clearTimeout(u),u=null,v(!1),m("エラー","シリアルモニタを確認してください","error"),l("error",t)}function G(t="手動で実行を停止しました。"){x&&(clearTimeout(u),u=null,c?.terminate(),c=null,v(!1),m("停止","次回実行時に環境を再起動します","error"),l("warning",t))}async function U(){if(x)return;if(!r){g("先に入力画像を選択してください。"),s.imageFile.focus();return}v(!0),m("開始中","入力データを準備しています","busy"),l("system","コードを実行します。");const t=new Uint8ClampedArray(r.data),e=new Uint8Array(w),n={type:"run",code:s.code.value,image:{width:r.width,height:r.height,data:t.buffer},uart:e.buffer,gpio:{...p}},a=[t.buffer,e.buffer];j().postMessage(n,a)}function I(t,e,n="IN"){const a=document.querySelector(`[data-gpio="${t}"]`);a&&(a.classList.toggle("high",!!e),a.setAttribute("aria-pressed",String(!!e)),a.querySelector("b").textContent=`${n} ${e?"HIGH":"LOW"}`)}function O(t){document.querySelectorAll("[data-led]").forEach((e,n)=>{const a=t[n]||[0,0,0];e.style.setProperty("--led-color",`rgb(${a[0]},${a[1]},${a[2]})`),e.classList.toggle("on",a.some(Number))})}async function M(){const t={version:1,app:"UnitV Browser Lab",savedAt:new Date().toISOString(),code:s.code.value,uart:{value:s.uart.value,format:s.uartFormat.value},gpio:{...p},image:{name:h}};i("#embed-image").checked&&b&&(t.image.dataUrl=b),L(new Blob([JSON.stringify(t,null,2)],{type:"application/json"}),"unitv-project.unitvproj"),i("#save-dialog").close(),l("system","プロジェクトを保存しました。")}async function F(t){const e=JSON.parse(await t.text());if(e.version!==1)throw new Error(`未対応のプロジェクトバージョンです: ${e.version}`);s.code.value=String(e.code||_.color),f(),s.uart.value=e.uart?.value||"",s.uartFormat.value=e.uart?.format||"text",p={GPIO1:0,GPIO2:0,GPIOHS0:0,...e.gpio||{}},Object.entries(p).forEach(([n,a])=>I(n,a)),e.image?.dataUrl&&await R(e.image.dataUrl,e.image.name),l("system",`プロジェクトを開きました: ${t.name}`)}s.code.addEventListener("input",f);s.code.addEventListener("scroll",()=>{s.lines.scrollTop=s.code.scrollTop});s.code.addEventListener("keydown",t=>{if(t.key==="Tab"){t.preventDefault();const e=s.code.selectionStart,n=s.code.selectionEnd;s.code.setRangeText("    ",e,n,"end"),f()}(t.ctrlKey||t.metaKey)&&t.key==="Enter"&&(t.preventDefault(),U())});i("#sample-select").addEventListener("change",t=>{s.code.value=_[t.target.value],f()});s.imageFile.addEventListener("change",async t=>{try{await E(t.target.files[0])}catch(e){g(e.message)}});i("#sample-image").addEventListener("click",S);s.run.addEventListener("click",U);s.stop.addEventListener("click",()=>G());i("#clear-log").addEventListener("click",()=>{s.terminal.innerHTML="",l("system","ログを消去しました。")});i("#download-image").addEventListener("click",()=>s.canvas.toBlob(t=>t&&L(t,"unitv-output.png"),"image/png"));i("#uart-queue").addEventListener("click",()=>{try{w=$(),l("system",`UART受信キューに ${w.length} byte を設定しました。`)}catch(t){g(t.message)}});document.querySelectorAll("[data-gpio]").forEach(t=>t.addEventListener("click",()=>{const e=t.dataset.gpio;p[e]=p[e]?0:1,I(e,p[e])}));i("#api-open").addEventListener("click",()=>i("#api-dialog").showModal());i("#project-save").addEventListener("click",()=>i("#save-dialog").showModal());i("#confirm-save").addEventListener("click",M);i("#project-open").addEventListener("click",()=>i("#project-file").click());i("#project-file").addEventListener("change",async t=>{try{await F(t.target.files[0])}catch(e){g(`プロジェクトを開けません: ${e.message}`)}t.target.value=""});document.querySelectorAll("dialog").forEach(t=>t.addEventListener("click",e=>{e.target===t&&t.close()}));window.addEventListener("beforeunload",()=>c?.terminate());

function Ce(e=""){const t=String(e).replace(/\\/g,"/"),r=t.match(/\/unitv-project-[^/]+\/(.+)$/);return r?r[1]:t.replace(/^\.\//,"")}function Le(e,t){const r=String(e||""),s=String(t||"");return r.includes("Traceback")||/File "[^"]+", line \d+/.test(r)?r.split(/\r?\n/):s.split(/\r?\n/)}function Ie(e,t){const r=e[t+1]||"",s=e[t+2]||"";if(!/[\^~]/.test(s))return{};const n=r.startsWith("    ")&&s.startsWith("    ")?4:0,a=s.slice(n),i=a.search(/[\^~]/);if(i<0)return{};let o=i;for(;o<a.length&&/[\^~]/.test(a[o]);)o+=1;return{column:i+1,endColumn:Math.max(i+2,o+1)}}function Ee(e,t=""){const r=Le(e,t),s=[];r.forEach((h,d)=>{const g=h.match(/^\s*File "([^"]+)", line (\d+)(?:, in (.+))?/);g&&s.push({filename:Ce(g[1]),line:Number(g[2]),functionName:g[3]||"",index:d})});const a=s.filter(h=>h.filename&&!h.filename.startsWith("<")).at(-1)||s.at(-1)||null,i=[...r].reverse().find(h=>/^\s*[A-Za-z_][\w.]*?(?:Error|Exception|Interrupt)(?::|$)/.test(h))||String(e||"").split(/\r?\n/).at(-1)||"PythonError",o=i.trim().match(/^([A-Za-z_][\w.]*(?:Error|Exception|Interrupt))(?::\s*(.*))?$/),l=o?.[1]||"PythonError",u=o?.[2]||i.trim().replace(/^PythonError:\s*/,"")||"不明なPythonエラー";return{type:l,reason:u,filename:a?.filename||"",line:a?.line||null,endLine:a?.line||null,...a?Ie(r,a.index):{},rawMessage:String(e||""),stack:String(t||"")}}function ke(e,t,r){const s=String(e).split(`
`),n=[];return{code:s.map((i,o)=>{let l=0;return i.replace(t,(...h)=>{const d=h[0],g=h.at(-2),y=r(d,...h.slice(1,-2)),x=g+l;return n.push({line:o+1,originalStart:g,originalLength:d.length,preparedStart:x,preparedLength:y.length}),l+=y.length-d.length,y})}).join(`
`),mappings:n}}function Re(e,t=!1){const r=/^while\s*\(?\s*(?:True|1)\s*\)?\s*:/g;if(t){const n=ke(e,r,()=>"while await bridge.loopCondition():");return{prepared:n.code,mappings:n.mappings,limited:!1}}const s=ke(e,r,()=>"for __unitv_browser_frame in range(1):");return{prepared:s.code,mappings:s.mappings,limited:s.mappings.length>0}}function Te(e,t=[]){if(!e?.line||!e?.column)return e;const r=t.filter(n=>n.line===e.line).sort((n,a)=>n.preparedStart-a.preparedStart),s=n=>{if(!n)return n;const a=n-1;let i=0;for(const o of r){if(a<o.preparedStart)break;if(a<=o.preparedStart+o.preparedLength)return o.originalStart+Math.min(Math.max(0,a-o.preparedStart),o.originalLength)+1;i+=o.preparedLength-o.originalLength}return Math.max(1,a-i+1)};return{...e,column:s(e.column),endColumn:s(e.endColumn||e.column+1)}}const Oe={1:"kmodelヘッダーが短すぎます",2:"kmodel v3ではありません",3:"16 bit重みのkmodelには未対応です",4:"K210以外のアーキテクチャです",5:"レイヤーまたは出力定義が不正です",6:"ヘッダーテーブルが壊れています",7:"出力メモリ範囲が不正です",8:"レイヤー本体が壊れています",9:"K210畳み込みレイヤーが不正です",10:"Dequantizeレイヤーが不正です",11:"このkmodelに未対応のレイヤーがあります",12:"入出力形状を取得できません",13:"kmodel実行用メモリを確保できません",20:"入力画像のサイズが不足しています",21:"畳み込みを実行できません",22:"Dequantizeのメモリ範囲が不正です",23:"実行時に未対応レイヤーが見つかりました"},U=(e,t)=>e.getUint32(t,!0);function Fe(e){const t=e instanceof Uint8Array?e:new Uint8Array(e);if(t.byteLength<28)throw new Error("kmodelヘッダーが短すぎます。");const r=new DataView(t.buffer,t.byteOffset,t.byteLength),s=U(r,0),n=U(r,4),a=U(r,8),i=U(r,12),o=U(r,20),l=U(r,24);if(s!==3)throw new Error(`kmodel v3のみ対応しています（このファイルはv${s}です）。`);if(a!==0)throw new Error(`K210用kmodelではありません（arch=${a}）。`);if(!(n&1))throw new Error("初版ランタイムは8 bit重みのkmodel v3のみ対応しています。");const u=28+l*8+i*8;if(!i||!l||u>t.byteLength)throw new Error("kmodelのヘッダーまたはレイヤーテーブルが壊れています。");const h=Array.from({length:l},(x,N)=>({address:U(r,28+N*8),size:U(r,32+N*8)}));let d=u;const g=Array.from({length:i},(x,N)=>{const k=28+l*8+N*8,S={type:U(r,k),size:U(r,k+4),offset:d};return d+=S.size,S});if(d>t.byteLength)throw new Error("kmodelのレイヤー本体が途中で切れています。");const y=g.filter(x=>![12,10240].includes(x.type));return{version:s,flags:n,arch:a,layers:i,mainMemory:o,outputs:h,layerList:g,unsupported:y}}let me;async function $e(){return me||(me=(async()=>{const e=new URL("/kpu/kmodel-runtime.wasm",self.location.href),t=await fetch(e);if(!t.ok)throw new Error(`KPUランタイムを読み込めませんでした（HTTP ${t.status}）。`);return WebAssembly.compile(await t.arrayBuffer())})()),me}function Ne(e,t){const r=Number(e.model_last_error());return new Error(`${t}: ${Oe[r]||`不明なKPUエラー (${r})`}`)}function Me(e){return String(e||"").replace(/\\/g,"/").replace(/^\/+/,"").replace(/^sd\//i,"")}function pe(e){return 1/(1+Math.exp(-e))}function Ae(e,t,r,s){return Math.min(e+t/2,r+s/2)-Math.max(e-t/2,r-s/2)}function Be(e,t){const r=Ae(e.x,e.w,t.x,t.w),s=Ae(e.y,e.h,t.y,t.h);if(r<0||s<0)return 0;const n=r*s,a=e.w*e.h+t.w*t.h-n;return a>0?n/a:0}function Ge(e,t,r){const s=Number(t.width),n=Number(t.height),a=Number(t.channels),i=Array.from(r.anchors||[],Number),o=Number(r.anchorCount||i.length/2),l=Number(r.threshold??.5),u=Number(r.nmsThreshold??.3);if(!o||i.length<o*2)throw new Error("YOLOアンカーの個数または値が不足しています。");const h=a/o-5;if(!Number.isInteger(h)||h<1)throw new Error(`出力チャンネル数 ${a} とアンカー数 ${o} からクラス数を計算できません。`);const d=Float32Array.from(e),g=s*n,y=(f,w,_)=>f*g*(h+5)+_*g+w;for(let f=0;f<o;f++)for(let w=0;w<g;w++){d[y(f,w,0)]=pe(d[y(f,w,0)]),d[y(f,w,1)]=pe(d[y(f,w,1)]),d[y(f,w,4)]=pe(d[y(f,w,4)]);let _=-1/0,m=0;for(let c=0;c<h;c++)_=Math.max(_,d[y(f,w,5+c)]);for(let c=0;c<h;c++){const p=Math.exp(d[y(f,w,5+c)]-_);d[y(f,w,5+c)]=p,m+=p}for(let c=0;c<h;c++)d[y(f,w,5+c)]/=m}const x=[];for(let f=0;f<g;f++){const w=Math.floor(f/s),_=f%s;for(let m=0;m<o;m++){const c=d[y(m,f,4)],p=Array.from({length:h},(b,M)=>{const R=c*d[y(m,f,5+M)];return R>l?R:0});x.push({x:(_+d[y(m,f,0)])/s,y:(w+d[y(m,f,1)])/n,w:Math.exp(d[y(m,f,2)])*i[m*2]/s,h:Math.exp(d[y(m,f,3)])*i[m*2+1]/n,probabilities:p})}}for(let f=0;f<h;f++){const w=x.map((_,m)=>({box:_,index:m})).sort((_,m)=>m.box.probabilities[f]-_.box.probabilities[f]);for(let _=0;_<w.length;_++)if(w[_].box.probabilities[f])for(let m=_+1;m<w.length;m++)Be(w[_].box,w[m].box)>u&&(w[m].box.probabilities[f]=0)}const N=Number(r.imageWidth||t.inputWidth),k=Number(r.imageHeight||t.inputHeight),S=[];for(const f of x){let w=0;for(let M=1;M<h;M++)f.probabilities[M]>f.probabilities[w]&&(w=M);const _=f.probabilities[w];if(!(_>l))continue;const m=Math.trunc((f.x-f.w/2)*N),c=Math.trunc((f.y-f.h/2)*k),p=Math.trunc((f.x+f.w/2)*N),b=Math.trunc((f.y+f.h/2)*k);S.push({x:m,y:c,w:p-m,h:b-c,value:_,classId:w})}return S}class ze{constructor(t,r,s){if(this.name=r,this.metadata=Fe(s),this.metadata.unsupported.length){const o=[...new Set(this.metadata.unsupported.map(l=>l.type))].join(", ");throw new Error(`このkmodelには初版ランタイム未対応のレイヤーがあります: ${o}`)}this.instance=new WebAssembly.Instance(t,{});const n=this.instance.exports;n.arena_reset();const a=s instanceof Uint8Array?s:new Uint8Array(s),i=n.arena_alloc(a.byteLength);if(!i)throw new Error("kmodel用メモリを確保できません。");if(new Uint8Array(n.memory.buffer,i,a.byteLength).set(a),n.model_init(i,a.byteLength))throw Ne(n,"kmodelを初期化できません");if(this.inputPointer=n.arena_alloc(n.model_input_width()*n.model_input_height()*n.model_input_channels()),!this.inputPointer)throw new Error("KPU入力バッファを確保できません。");this.shape={inputWidth:Number(n.model_input_width()),inputHeight:Number(n.model_input_height()),inputChannels:Number(n.model_input_channels()),width:Number(n.model_output_width()),height:Number(n.model_output_height()),channels:Number(n.model_output_channels())},this.yolo=null}run(t){const r=this.instance.exports;if(t.byteLength!==this.shape.inputWidth*this.shape.inputHeight*this.shape.inputChannels)throw new Error("KPU入力画像のサイズがモデルと一致しません。");if(new Uint8Array(r.memory.buffer,this.inputPointer,t.byteLength).set(t),r.model_run(this.inputPointer,t.byteLength))throw Ne(r,"KPU推論に失敗しました");const s=Number(r.model_output_size())/4;return Float32Array.from(new Float32Array(r.memory.buffer,Number(r.model_output_ptr()),s))}}class ge{static async create(t=[]){const r=new ge;return r.module=t.length?await $e():null,r.files=new Map(t.map(s=>[Me(s.name),s.data])),r.tasks=new Map,r.nextId=1,r}available(){return this.files.size>0}load(t){if(!this.available())throw new Error("プロジェクトに.kmodelファイルがありません。FILESへ追加してください。");const r=Me(t);let s=this.files.get(r),n=r;if(!s){const o=r.split("/").pop(),l=[...this.files.entries()].find(([u])=>u===o||u.endsWith(`/${o}`));l&&([n,s]=l)}if(!s&&this.files.size===1&&([n,s]=this.files.entries().next().value),!s)throw new Error(`kmodelが見つかりません: ${t}`);const a=new ze(this.module,n,s),i=this.nextId++;return this.tasks.set(i,a),i}task(t){const r=this.tasks.get(Number(t));if(!r)throw new Error("KPUタスクが無効です。kpu.load()を先に呼び出してください。");return r}initYolo(t,r,s,n,a){const i=this.task(t);if(i.yolo={threshold:Number(r),nmsThreshold:Number(s),anchorCount:Number(n),anchors:Array.from(a,Number)},i.shape.channels!==i.yolo.anchorCount*Math.floor(i.shape.channels/i.yolo.anchorCount))throw new Error("モデル出力とアンカー数が一致しません。");return!0}forward(t,r){return this.task(t).run(r)}runYolo(t,r){const s=this.task(t);if(!s.yolo)throw new Error("kpu.init_yolo2()を先に呼び出してください。");return Ge(s.run(r),s.shape,{...s.yolo,imageWidth:s.shape.inputWidth,imageHeight:s.shape.inputHeight})}deinit(t){this.tasks.delete(Number(t))}}const V={QQVGA:[160,120],QVGA:[320,240],VGA:[640,480],QQQVGA:[80,60],B64X64:[64,64],B128X128:[128,128],LCD:[320,240]};let K=null,C=null,z=V.QVGA,F=null,j=!1,Q=!1,J=0,X=0,Z=0,ae={},L=[],v={},W=[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],E=null,se=null,I=!1,De=0;const q=new Map;let Y=[];const $=(e,t=0,r=255)=>Math.max(t,Math.min(r,Number(e)||0)),A=(e,t={})=>self.postMessage({type:e,...t}),ie=()=>new Date().toLocaleTimeString("ja-JP",{hour12:!1});function We(){if(!I||!C)return;const e=new Uint8ClampedArray(C.data);self.postMessage({type:"frame",width:C.width,height:C.height,data:e.buffer},[e.buffer])}function Se(){We();const e=++De;return A("camera-frame-request",{requestId:e}),new Promise((t,r)=>q.set(e,{resolve:t,reject:r}))}function P(e){return e==null?e:typeof e.toJs=="function"?e.toJs({dict_converter:Object.fromEntries}):ArrayBuffer.isView(e)?Array.from(e):e}function D(e,t=[255,255,255]){const r=P(e);if(typeof r=="number")return[r,r,r,255].map((n,a)=>a===3?255:$(n));const s=Array.isArray(r)?r:t;return[$(s[0]),$(s[1]),$(s[2]),255]}function ye(e){return{width:e.width,height:e.height,data:new Uint8ClampedArray(e.data)}}function we(e,t,r){t=Math.max(1,Math.floor(t)),r=Math.max(1,Math.floor(r));const s=new Uint8ClampedArray(t*r*4);for(let n=0;n<r;n++){const a=Math.min(e.height-1,Math.floor(n*e.height/r));for(let i=0;i<t;i++){const o=Math.min(e.width-1,Math.floor(i*e.width/t)),l=(a*e.width+o)*4,u=(n*t+i)*4;s[u]=e.data[l],s[u+1]=e.data[l+1],s[u+2]=e.data[l+2],s[u+3]=255}}return{width:t,height:r,data:s}}function oe(e,t){const[r,s,n,a]=t.map(Number),i=Math.max(0,Math.floor(r)),o=Math.max(0,Math.floor(s)),l=Math.max(1,Math.min(e.width-i,Math.floor(n))),u=Math.max(1,Math.min(e.height-o,Math.floor(a))),h=new Uint8ClampedArray(l*u*4);for(let d=0;d<u;d++){const g=((o+d)*e.width+i)*4;h.set(e.data.subarray(g,g+l*4),d*l*4)}return{width:l,height:u,data:h}}function He(e){if(!j&&!Q)return e;const t=new Uint8ClampedArray(e.data.length);for(let r=0;r<e.height;r++)for(let s=0;s<e.width;s++){const n=j?e.width-1-s:s,a=Q?e.height-1-r:r;t.set(e.data.subarray((a*e.width+n)*4,(a*e.width+n)*4+4),(r*e.width+s)*4)}return{width:e.width,height:e.height,data:t}}function Ke(e){if(!J&&!X&&!Z)return e;const t=Number(J)*12,r=1+Number(Z)*.12,s=1+Number(X)*.16;for(let n=0;n<e.data.length;n+=4){let a=(e.data[n]-128)*r+128+t,i=(e.data[n+1]-128)*r+128+t,o=(e.data[n+2]-128)*r+128+t;const l=.299*a+.587*i+.114*o;e.data[n]=$(l+(a-l)*s),e.data[n+1]=$(l+(i-l)*s),e.data[n+2]=$(l+(o-l)*s)}return e}function qe(e,t,r){e/=255,t/=255,r/=255,e=e>.04045?((e+.055)/1.055)**2.4:e/12.92,t=t>.04045?((t+.055)/1.055)**2.4:t/12.92,r=r>.04045?((r+.055)/1.055)**2.4:r/12.92;let s=(e*.4124+t*.3576+r*.1805)/.95047,n=e*.2126+t*.7152+r*.0722,a=(e*.0193+t*.1192+r*.9505)/1.08883;const i=o=>o>.008856?Math.cbrt(o):7.787*o+16/116;return s=i(s),n=i(n),a=i(a),[116*n-16,500*(s-n),200*(n-a)]}function Ue(e,t,r,s){for(const n of s)if(n.length>=6){const[a,i,o]=qe(e,t,r);if(a>=n[0]&&a<=n[1]&&i>=n[2]&&i<=n[3]&&o>=n[4]&&o<=n[5])return!0}else if(n.length>=2){const a=.299*e+.587*t+.114*r;if(a>=n[0]&&a<=n[1])return!0}return!1}function Ve(e,t,r,s){let n=0;return s.forEach((a,i)=>{Ue(e,t,r,[a])&&(n|=1<<i)}),n}function _e(e,t,r,s){if(t=Math.round(t),r=Math.round(r),t<0||r<0||t>=e.width||r>=e.height)return;const n=(r*e.width+t)*4;e.data[n]=s[0],e.data[n+1]=s[1],e.data[n+2]=s[2],e.data[n+3]=255}function B(e,t,r,s,n,a,i=1){t=Math.round(t),r=Math.round(r),s=Math.round(s),n=Math.round(n);const o=Math.abs(s-t),l=t<s?1:-1,u=-Math.abs(n-r),h=r<n?1:-1;let d=o+u;for(;;){const g=Math.max(0,Math.floor(i/2));for(let x=-g;x<=g;x++)for(let N=-g;N<=g;N++)_e(e,t+N,r+x,a);if(t===s&&r===n)break;const y=2*d;y>=u&&(d+=u,t+=l),y<=o&&(d+=o,r+=h)}}function Ye(e,t,r,s=1,n=!1){const[a,i,o,l]=t.map(Number);if(n){for(let u=i;u<i+l;u++)for(let h=a;h<a+o;h++)_e(e,h,u,r);return}B(e,a,i,a+o,i,r,s),B(e,a,i+l,a+o,i+l,r,s),B(e,a,i,a,i+l,r,s),B(e,a+o,i,a+o,i+l,r,s)}function je(e,t,r,s,n,a=1,i=!1){const o=Number(s),l=i?0:Math.max(0,o-a);for(let u=Math.floor(r-o);u<=Math.ceil(r+o);u++)for(let h=Math.floor(t-o);h<=Math.ceil(t+o);h++){const d=Math.hypot(h-t,u-r);d<=o&&d>=l&&_e(e,h,u,n)}}function Qe(e,t,r,s,n,a=1){if(typeof OffscreenCanvas>"u")return;const o=new OffscreenCanvas(e.width,e.height).getContext("2d");o.putImageData(new ImageData(e.data,e.width,e.height),0,0),o.fillStyle=`rgb(${n[0]},${n[1]},${n[2]})`,o.font=`${Math.max(10,12*Number(a))}px monospace`,o.textBaseline="top",o.fillText(String(s),Number(t),Number(r)),e.data=o.getImageData(0,0,e.width,e.height).data}function ve(e){const t=P(e)||[];return Array.isArray(t)?t.map(r=>Array.from(r,Number)):[]}class le{constructor(t){this.frame=t,C=t}width(){return this.frame.width}height(){return this.frame.height}size(){return this.frame.data.length}resize(t,r){return this.frame=we(this.frame,t,r),C=this.frame,this}crop(t){return this.frame=oe(this.frame,Array.from(P(t))),C=this.frame,this}copy(t){return t==null?new le(ye(this.frame)):new le(oe(this.frame,Array.from(P(t))))}binary(t,r=!1){const s=ve(t);for(let n=0;n<this.frame.data.length;n+=4){let a=Ue(this.frame.data[n],this.frame.data[n+1],this.frame.data[n+2],s);r&&(a=!a);const i=a?255:0;this.frame.data[n]=i,this.frame.data[n+1]=i,this.frame.data[n+2]=i}return C=this.frame,this}findBlobs(t,r,s=2,n=1,a=!1,i=10,o=10,l=!1,u=0){const h=ve(t),d=r==null?[0,0,this.frame.width,this.frame.height]:Array.from(P(r),Number),g=Math.max(0,d[0]|0),y=Math.max(0,d[1]|0),x=Math.min(this.frame.width,g+(d[2]|0)),N=Math.min(this.frame.height,y+(d[3]|0)),k=x-g,S=N-y,f=new Uint32Array(k*S),w=new Uint8Array(k*S);for(let m=0;m<S;m++)for(let c=0;c<k;c++){const p=((m+y)*this.frame.width+c+g)*4;let b=Ve(this.frame.data[p],this.frame.data[p+1],this.frame.data[p+2],h);a&&(b=b?0:1),f[m*k+c]=b}const _=[];for(let m=0;m<S;m+=Math.max(1,Number(n)))for(let c=0;c<k;c+=Math.max(1,Number(s))){const p=m*k+c;if(!f[p]||w[p])continue;const b=[c],M=[m];w[p]=1;const R=f[p];let H=0,G=0,ee=c,de=c,te=m,ue=m,be=0,xe=0;for(;H<b.length;){const T=b[H],O=M[H++];G++,be+=T,xe+=O,ee=Math.min(ee,T),de=Math.max(de,T),te=Math.min(te,O),ue=Math.max(ue,O);for(const[re,ne]of[[T-1,O],[T+1,O],[T,O-1],[T,O+1]]){if(re<0||ne<0||re>=k||ne>=S)continue;const ce=ne*k+re;f[ce]===R&&!w[ce]&&(w[ce]=1,b.push(re),M.push(ne))}}const fe=de-ee+1,he=ue-te+1;G>=Number(o)&&fe*he>=Number(i)&&_.push({x:ee+g,y:te+y,w:fe,h:he,pixels:G,cx:Math.round(be/G)+g,cy:Math.round(xe/G)+y,density:G/(fe*he),rotation:0,code:R})}if(l&&_.length>1){const m=[];for(const c of _.sort((p,b)=>b.pixels-p.pixels)){const p=m.find(b=>c.x<=b.x+b.w+u&&c.x+c.w+u>=b.x&&c.y<=b.y+b.h+u&&c.y+c.h+u>=b.y);if(!p)m.push({...c});else{const b=Math.min(p.x,c.x),M=Math.min(p.y,c.y),R=Math.max(p.x+p.w,c.x+c.w),H=Math.max(p.y+p.h,c.y+c.h);p.pixels+=c.pixels,p.code|=c.code,p.x=b,p.y=M,p.w=R-b,p.h=H-M,p.cx=Math.round(b+p.w/2),p.cy=Math.round(M+p.h/2),p.density=p.pixels/(p.w*p.h)}}return m}return _.sort((m,c)=>c.pixels-m.pixels)}drawRectangle(t,r,s=1,n=!1){return Ye(this.frame,Array.from(P(t)),D(r),Number(s),!!n),this}drawLine(t,r,s=1){const n=Array.from(P(t));return B(this.frame,n[0],n[1],n[2],n[3],D(r),Number(s)),this}drawCircle(t,r,s,n,a=1,i=!1){return je(this.frame,Number(t),Number(r),Number(s),D(n),Number(a),!!i),this}drawCross(t,r,s,n=5,a=1){const i=D(s);return B(this.frame,t-n,r,t+n,r,i,a),B(this.frame,t,r-n,t,r+n,i,a),this}drawString(t,r,s,n,a=1){return Qe(this.frame,t,r,s,D(n),a),this}}function Pe(e,t){const r=E.task(e),s=we(t.frame,r.shape.inputWidth,r.shape.inputHeight),{inputWidth:n,inputHeight:a,inputChannels:i}=r.shape,o=new Uint8Array(n*a*i);for(let l=0;l<a;l++)for(let u=0;u<n;u++){const h=(l*n+u)*4,d=l*n+u;if(i===1)o[d]=Math.round(.299*s.data[h]+.587*s.data[h+1]+.114*s.data[h+2]);else{o[d]=s.data[h],o[n*a+d]=s.data[h+1],o[n*a*2+d]=s.data[h+2];for(let g=3;g<i;g++)o[n*a*g+d]=0}}return o}function Je(){return{requestCameraFrame:Se,loopCondition:async()=>(I?await Se():await new Promise(e=>setTimeout(e,0)),!0),sensorReset:()=>(z=V.QVGA,F=null,j=!1,Q=!1,J=0,X=0,Z=0,ae={},!0),setFrameSize:e=>{const t=P(e);z=Array.isArray(t)?t.map(Number):V[String(t)]||V.QVGA},setWindowing:e=>{F=Array.from(P(e),Number)},setHMirror:e=>{j=!!e},setVFlip:e=>{Q=!!e},setBrightness:e=>{J=Number(e)||0},setSaturation:e=>{X=Number(e)||0},setContrast:e=>{Z=Number(e)||0},readRegister:e=>Number(ae[Number(e)]||0),writeRegister:(e,t)=>{ae[Number(e)]=Number(t)&255},snapshot:()=>{let e=He(ye(K));if(z&&(e=we(e,z[0],z[1])),F?.length===2){const[t,r]=F;e=oe(e,[(e.width-t)/2,(e.height-r)/2,t,r])}else F?.length>=4&&(e=oe(e,F));return e=Ke(e),new le(e)},imageWidth:e=>e.width(),imageHeight:e=>e.height(),imageSize:e=>e.size(),imageResize:(e,t,r)=>e.resize(t,r),imageCrop:(e,t)=>e.crop(t),imageCopy:(e,t)=>e.copy(t),imageBinary:(e,t,r)=>e.binary(t,r),imageFindBlobs:(e,t,r,s,n,a,i,o,l,u)=>e.findBlobs(t,r,s,n,a,i,o,l,u),drawRectangle:(e,t,r,s,n)=>e.drawRectangle(t,r,s,n),drawLine:(e,t,r,s)=>e.drawLine(t,r,s),drawCircle:(e,t,r,s,n,a,i)=>e.drawCircle(t,r,s,n,a,i),drawCross:(e,t,r,s,n,a)=>e.drawCross(t,r,s,n,a),drawString:(e,t,r,s,n,a)=>e.drawString(t,r,s,n,a),log:(...e)=>{const t=e.map(String).join(" ");Y.push(t),Y.length>120&&Y.shift(),A("log",{level:"stdout",text:t,time:ie()})},uartWrite:e=>{const t=P(e),r=typeof t=="string"?new TextEncoder().encode(t):Uint8Array.from(t);return A("log",{level:"uart",text:new TextDecoder().decode(r),bytes:Array.from(r),time:ie()}),r.length},uartAny:()=>L.length,uartRead:e=>{const t=e==null||Number(e)<0?L.length:Math.min(Number(e),L.length);return Uint8Array.from(L.splice(0,t))},uartReadline:()=>{const e=L.indexOf(10),t=e<0?L.length:e+1;return t?Uint8Array.from(L.splice(0,t)):null},gpioInit:(e,t,r,s=0)=>{const n=String(e);return n in v||(v[n]=Number(t)===0&&Number(r)===1?1:+!!s),A("gpio",{pin:n,value:v[n],mode:Number(t)===0?"IN":"OUT"}),v[n]},gpioGet:e=>Number(v[String(e)]||0),gpioSet:(e,t,r="OUT")=>(v[String(e)]=+!!t,A("gpio",{pin:String(e),value:v[String(e)],mode:String(r)}),v[String(e)]),ledSet:(e,t)=>{const r=Math.max(0,Number(e)|0);for(;W.length<=r;)W.push([0,0,0]);W[r]=D(t).slice(0,3)},ledDisplay:()=>A("led",{colors:W}),kpuAvailable:()=>!!E?.available(),kpuLoad:e=>E.load(String(e)),kpuDeinit:e=>E.deinit(Number(e)),kpuInitYolo:(e,t,r,s,n)=>E.initYolo(Number(e),t,r,s,P(n)),kpuForward:(e,t)=>Array.from(E.forward(Number(e),Pe(Number(e),t))),kpuRunYolo:(e,t)=>E.runYolo(Number(e),Pe(Number(e),t)),unsupported:e=>{throw new Error(`未対応のAPIです: ${e}`)}}}const Xe=String.raw`
import sys, types, builtins
from js import bridge

class Blob:
    def __init__(self, d): self._d=d
    def x(self): return int(self._d.x)
    def y(self): return int(self._d.y)
    def w(self): return int(self._d.w)
    def h(self): return int(self._d.h)
    def cx(self): return int(self._d.cx)
    def cy(self): return int(self._d.cy)
    def pixels(self): return int(self._d.pixels)
    def area(self): return self.w()*self.h()
    def rotation(self): return float(self._d.rotation)
    def code(self): return int(self._d.code)
    def density(self): return float(self._d.density)
    def rect(self): return (self.x(),self.y(),self.w(),self.h())
    def __getitem__(self,i): return (self.x(),self.y(),self.w(),self.h(),self.pixels(),self.cx(),self.cy())[i]
    def __repr__(self): return "Blob(x={}, y={}, w={}, h={}, pixels={})".format(self.x(),self.y(),self.w(),self.h(),self.pixels())

class SimImage:
    def __init__(self, handle=None):
        if handle is None: raise RuntimeError('image.Image(path) は未対応です。sensor.snapshot() を使用してください。')
        self._h=handle
    def width(self): return int(bridge.imageWidth(self._h))
    def height(self): return int(bridge.imageHeight(self._h))
    def size(self): return int(bridge.imageSize(self._h))
    def resize(self,w,h): bridge.imageResize(self._h,w,h); return self
    def crop(self,roi): bridge.imageCrop(self._h,roi); return self
    def copy(self,roi=None): return SimImage(bridge.imageCopy(self._h,roi))
    def binary(self,thresholds,invert=False,**kwargs): bridge.imageBinary(self._h,thresholds,invert); return self
    def find_blobs(self,thresholds,roi=None,x_stride=2,y_stride=1,invert=False,area_threshold=10,pixels_threshold=10,merge=False,margin=0,**kwargs):
        result=bridge.imageFindBlobs(self._h,thresholds,roi,x_stride,y_stride,invert,area_threshold,pixels_threshold,merge,margin)
        return [Blob(x) for x in result]
    def draw_rectangle(self,rect,color=(255,255,255),thickness=1,fill=False,**kwargs): bridge.drawRectangle(self._h,rect,color,thickness,fill); return self
    def draw_line(self,line,color=(255,255,255),thickness=1,**kwargs): bridge.drawLine(self._h,line,color,thickness); return self
    def draw_circle(self,x,y,radius,color=(255,255,255),thickness=1,fill=False,**kwargs): bridge.drawCircle(self._h,x,y,radius,color,thickness,fill); return self
    def draw_cross(self,x,y,color=(255,255,255),size=5,thickness=1,**kwargs): bridge.drawCross(self._h,x,y,color,size,thickness); return self
    def draw_string(self,x,y,text,color=(255,255,255),scale=1,**kwargs): bridge.drawString(self._h,x,y,str(text),color,scale); return self

image=types.ModuleType('image'); image.Image=SimImage; sys.modules['image']=image
sensor=types.ModuleType('sensor')
sensor.RGB565='RGB565'; sensor.GRAYSCALE='GRAYSCALE'; sensor.YUV422='YUV422'
for _name in ['QQVGA','QVGA','VGA','QQQVGA','B64X64','B128X128','LCD']: setattr(sensor,_name,_name)
sensor.reset=lambda *a,**k: bridge.sensorReset()
sensor.set_pixformat=lambda *a,**k: None
sensor.set_framesize=lambda value,*a,**k: bridge.setFrameSize(value)
sensor.set_windowing=lambda value,*a,**k: bridge.setWindowing(value)
sensor.set_hmirror=lambda value=True,*a,**k: bridge.setHMirror(value)
sensor.set_vflip=lambda value=True,*a,**k: bridge.setVFlip(value)
sensor.skip_frames=lambda *a,**k: None
sensor.run=lambda *a,**k: None
sensor.set_auto_gain=lambda *a,**k: None
sensor.set_auto_exposure=lambda *a,**k: None
sensor.set_auto_whitebal=lambda *a,**k: None
sensor.set_brightness=lambda value,*a,**k: bridge.setBrightness(value)
sensor.set_saturation=lambda value,*a,**k: bridge.setSaturation(value)
sensor.set_contrast=lambda value,*a,**k: bridge.setContrast(value)
sensor.__read_reg=lambda address: int(bridge.readRegister(address))
sensor.__write_reg=lambda address,value: bridge.writeRegister(address,value)
sensor.snapshot=lambda: SimImage(bridge.snapshot())
async def _snapshot_async():
    await bridge.requestCameraFrame()
    return sensor.snapshot()
sensor.snapshot_async=_snapshot_async
sys.modules['sensor']=sensor

class Clock:
    def __init__(self):
        self._last=_time.time(); self._fps=0
    def tick(self):
        now=_time.time(); delta=now-self._last; self._last=now; self._fps=(1/delta if delta else 0); return delta
    def fps(self): return self._fps
import time as _time
time_mod=types.ModuleType('time')
time_mod.sleep=_time.sleep; time_mod.sleep_ms=lambda ms:_time.sleep(ms/1000); time_mod.ticks_ms=lambda:int(_time.time()*1000); time_mod.clock=Clock
sys.modules['time']=time_mod

class UART:
    UART1=1; UART2=2; UART3=3
    def __init__(self,uart=1,baudrate=115200,*args,**kwargs): self.uart=uart; self.baudrate=baudrate
    def init(self,*args,**kwargs): return None
    def any(self): return int(bridge.uartAny())
    def read(self,n=-1):
        result=bridge.uartRead(n)
        return bytes(result) if result is not None else None
    def readchar(self):
        data=self.read(1); return data[0] if data else -1
    def readline(self):
        result=bridge.uartReadline(); return bytes(result) if result is not None else None
    def write(self,data):
        if isinstance(data,str): data=data.encode('utf-8')
        return int(bridge.uartWrite(list(data)))
    def deinit(self): return None
machine=types.ModuleType('machine'); machine.UART=UART; sys.modules['machine']=machine

class DynamicConstants:
    def __getattr__(self,name): return name
class FM:
    def __init__(self): self.fpioa=DynamicConstants()
    def register(self,*args,**kwargs): return None
    def unregister(self,*args,**kwargs): return None
fm=FM(); fpioa_manager=types.ModuleType('fpioa_manager'); fpioa_manager.fm=fm; sys.modules['fpioa_manager']=fpioa_manager
board=types.ModuleType('board'); board.board_info=DynamicConstants(); sys.modules['board']=board

class GPIO:
    IN=0; OUT=1; PULL_NONE=0; PULL_UP=1; PULL_DOWN=2
    GPIO0='GPIO0'; GPIO1='GPIO1'; GPIO2='GPIO2'; GPIOHS0='GPIOHS0'; GPIOHS1='GPIOHS1'; GPIOHS2='GPIOHS2'
    def __init__(self,pin,mode=OUT,pull=PULL_NONE,value=0,*args,**kwargs):
        self.pin=pin; self.mode=mode
        bridge.gpioInit(str(pin),mode,pull,value)
    def value(self,value=None):
        if value is None: return int(bridge.gpioGet(str(self.pin)))
        return int(bridge.gpioSet(str(self.pin),value,'IN' if self.mode==self.IN else 'OUT'))
Maix=types.ModuleType('Maix'); Maix.GPIO=GPIO; sys.modules['Maix']=Maix

class ws2812:
    def __init__(self,pin,led_num=1,*args,**kwargs): self.pin=pin; self.led_num=led_num
    def set_led(self,index,color): bridge.ledSet(index,color)
    def display(self): bridge.ledDisplay()
modules=types.ModuleType('modules'); modules.ws2812=ws2812; sys.modules['modules']=modules

class KPUResult:
    def __init__(self,values): self.values=list(values)
    def __len__(self): return len(self.values)
    def __getitem__(self,i): return self.values[i]
    def tolist(self): return list(self.values)
class Detection:
    def __init__(self,d): self._d=d
    def x(self): return int(self._d.x)
    def y(self): return int(self._d.y)
    def w(self): return int(self._d.w)
    def h(self): return int(self._d.h)
    def value(self): return float(self._d.value)
    def classid(self): return int(self._d.classId)
    def rect(self): return (self.x(),self.y(),self.w(),self.h())
    def __getitem__(self,i): return (self.x(),self.y(),self.w(),self.h(),self.value(),self.classid())[i]
    def __repr__(self): return "Detection(x={}, y={}, w={}, h={}, value={:.3f}, classid={})".format(self.x(),self.y(),self.w(),self.h(),self.value(),self.classid())
class KPUTask:
    def __init__(self,path): self.path=path; self._id=int(bridge.kpuLoad(path))
def _require_kpu():
    if not bridge.kpuAvailable(): raise RuntimeError('プロジェクトに.kmodelファイルがありません。FILESへ追加してください。')
kpu=types.ModuleType('KPU')
kpu.load=lambda path,*a,**k: KPUTask(path)
kpu.deinit=lambda task,*a,**k: bridge.kpuDeinit(task._id)
def _init_yolo(task,threshold,nms_value,anchor_num,anchors,*args,**kwargs):
    _require_kpu(); return bridge.kpuInitYolo(task._id,threshold,nms_value,anchor_num,anchors)
kpu.init_yolo2=_init_yolo
def _forward(task,img,*args,**kwargs): _require_kpu(); return KPUResult(bridge.kpuForward(task._id,img._h))
def _run_yolo(task,img,*args,**kwargs):
    _require_kpu(); result=[Detection(d) for d in bridge.kpuRunYolo(task._id,img._h)]; return result if result else None
kpu.forward=_forward; kpu.run_yolo2=_run_yolo; kpu.softmax=lambda values: KPUResult(values)
sys.modules['KPU']=kpu

_real_print=builtins.print
def sim_print(*args,sep=' ',end='\n',**kwargs): bridge.log(sep.join(str(x) for x in args)+end.rstrip('\n'))
builtins.print=sim_print
`;async function Ze(){if(se)return se;A("status",{phase:"loading-python",text:"Python環境を読み込んでいます"});const{loadPyodide:e}=await import(new URL("/pyodide/pyodide.mjs",self.location.href).href);return se=await e({indexURL:new URL("/pyodide/",self.location.href).href}),se}self.onmessage=async e=>{const t=e.data;if(t?.type==="uart-append"){L.push(...new Uint8Array(t.data||new ArrayBuffer(0)));return}if(t?.type==="gpio-update"){v[String(t.pin)]=+!!t.value;return}if(t?.type==="camera-frame"){const s=q.get(t.requestId);if(!s)return;q.delete(t.requestId),K={width:t.image.width,height:t.image.height,data:new Uint8ClampedArray(t.image.data)},s.resolve(!0);return}if(t?.type==="camera-frame-error"){const s=q.get(t.requestId);if(!s)return;q.delete(t.requestId),s.reject(new Error(t.message||"カメラフレームを取得できませんでした。"));return}if(t?.type!=="run")return;let r=[];try{Y=[],I=!!t.cameraMode,K={width:t.image.width,height:t.image.height,data:new Uint8ClampedArray(t.image.data)},C=ye(K),z=V.QVGA,F=null,j=!1,Q=!1,J=0,X=0,Z=0,ae={},L=Array.from(new Uint8Array(t.uart||new ArrayBuffer(0))),v={...t.gpio||{}},W=[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],t.models?.length&&A("status",{phase:"loading-kmodel",text:"K210 kmodelランタイムを読み込んでいます"}),E=await ge.create(t.models||[]);const s=await Ze();self.bridge=Je(),s.globals.set("bridge",self.bridge),await s.runPythonAsync(Xe);const n=`/unitv-project-${crypto.randomUUID()}`;s.FS.mkdirTree(n);for(const h of t.files||[]){const d=String(h.name||"").replace(/\\/g,"/").replace(/^\/+/,"");if(!d.endsWith(".py")||d.split("/").some(x=>!x||x==="."||x===".."))continue;const g=d.includes("/")?d.slice(0,d.lastIndexOf("/")):"";g&&s.FS.mkdirTree(`${n}/${g}`),s.FS.writeFile(`${n}/${d}`,String(h.code||""),{encoding:"utf8"});const y=d.replace(/\.py$/,"").replace(/\//g,".").replace(/\.__init__$/,"");await s.runPythonAsync(`import sys
sys.modules.pop(${JSON.stringify(y)}, None)`)}const a=String(t.filename||"").replace(/\\/g,"/").includes("/")?String(t.filename).replace(/\\/g,"/").slice(0,String(t.filename).replace(/\\/g,"/").lastIndexOf("/")):"";await s.runPythonAsync(`import os, sys, importlib
os.chdir(${JSON.stringify(n)})
sys.path.insert(0, ${JSON.stringify(n)})
sys.path.insert(0, ${JSON.stringify(`${n}/${a}`)})
importlib.invalidate_caches()`),A("status",{phase:"executing",text:I?"カメラフレームを連続処理しています":"コードを実行しています",liveCamera:I,kmodel:!!t.models?.length});const{prepared:i,limited:o,mappings:l}=Re(t.code,I);r=l,o&&A("log",{level:"system",text:"固定画像モードのためトップレベルの無限ループを1フレームだけ実行します。",time:ie()}),I&&A("log",{level:"system",text:"カメラモード: トップレベルの無限ループを維持し、ループごとに新しいフレームを取得します。停止ボタンで終了できます。",time:ie()}),await s.runPythonAsync(i,{filename:t.filename||"main.py"});const u=C||K;I=!1,A("result",{width:u.width,height:u.height,data:u.data.buffer,gpio:v,leds:W},[u.data.buffer])}catch(s){I=!1;const n=String(s?.message||s),a=String(s?.stack||""),i=Y.join(`
`),o=i.includes("Traceback")?i:n==="PythonError"&&a?a:n;let l=Ee(o,a);l.filename===String(t.filename||"").replace(/\\/g,"/")&&(l=Te(l,r)),A("error",{message:`${l.type}: ${l.reason}`,stack:a,error:l})}};

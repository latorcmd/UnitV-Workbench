function we(e=""){const t=String(e).replace(/\\/g,"/"),r=t.match(/\/unitv-project-[^/]+\/(.+)$/);return r?r[1]:t.replace(/^\.\//,"")}function be(e,t){const r=String(e||""),n=String(t||"");return r.includes("Traceback")||/File "[^"]+", line \d+/.test(r)?r.split(/\r?\n/):n.split(/\r?\n/)}function xe(e,t){const r=e[t+1]||"",n=e[t+2]||"";if(!/[\^~]/.test(n))return{};const s=r.startsWith("    ")&&n.startsWith("    ")?4:0,a=n.slice(s),i=a.search(/[\^~]/);if(i<0)return{};let l=i;for(;l<a.length&&/[\^~]/.test(a[l]);)l+=1;return{column:i+1,endColumn:Math.max(i+2,l+1)}}function Me(e,t=""){const r=be(e,t),n=[];r.forEach((h,f)=>{const m=h.match(/^\s*File "([^"]+)", line (\d+)(?:, in (.+))?/);m&&n.push({filename:we(m[1]),line:Number(m[2]),functionName:m[3]||"",index:f})});const a=n.filter(h=>h.filename&&!h.filename.startsWith("<")).at(-1)||n.at(-1)||null,i=[...r].reverse().find(h=>/^\s*[A-Za-z_][\w.]*?(?:Error|Exception|Interrupt)(?::|$)/.test(h))||String(e||"").split(/\r?\n/).at(-1)||"PythonError",l=i.trim().match(/^([A-Za-z_][\w.]*(?:Error|Exception|Interrupt))(?::\s*(.*))?$/),o=l?.[1]||"PythonError",d=l?.[2]||i.trim().replace(/^PythonError:\s*/,"")||"不明なPythonエラー";return{type:o,reason:d,filename:a?.filename||"",line:a?.line||null,endLine:a?.line||null,...a?xe(r,a.index):{},rawMessage:String(e||""),stack:String(t||"")}}function pe(e,t,r){const n=String(e).split(`
`),s=[];return{code:n.map((i,l)=>{let o=0;return i.replace(t,(...h)=>{const f=h[0],m=h.at(-2),_=r(f,...h.slice(1,-2)),y=m+o;return s.push({line:l+1,originalStart:m,originalLength:f.length,preparedStart:y,preparedLength:_.length}),o+=_.length-f.length,_})}).join(`
`),mappings:s}}function ke(e,t=!1){if(t){const n=pe(e,/\bsensor\s*\.\s*snapshot\s*\(\s*\)/g,()=>"await sensor.snapshot_async()");return{prepared:n.code,mappings:n.mappings,limited:!1}}const r=pe(e,/^while\s*\(?\s*True\s*\)?\s*:/g,()=>"for __unitv_browser_frame in range(1):");return{prepared:r.code,mappings:r.mappings,limited:r.mappings.length>0}}function Se(e,t=[]){if(!e?.line||!e?.column)return e;const r=t.filter(s=>s.line===e.line).sort((s,a)=>s.preparedStart-a.preparedStart),n=s=>{if(!s)return s;const a=s-1;let i=0;for(const l of r){if(a<l.preparedStart)break;if(a<=l.preparedStart+l.preparedLength)return l.originalStart+Math.min(Math.max(0,a-l.preparedStart),l.originalLength)+1;i+=l.preparedLength-l.originalLength}return Math.max(1,a-i+1)};return{...e,column:n(e.column),endColumn:n(e.endColumn||e.column+1)}}const D={QQVGA:[160,120],QVGA:[320,240],VGA:[640,480],QQQVGA:[80,60],B64X64:[64,64],B128X128:[128,128],LCD:[320,240]};let E=null,x=null,I=D.QVGA,P=null,z=!1,q=!1,Q=0,j=0,W=0,te={},S=[],R={},L=[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],Ne=null,ee=null,N=!1,Ae=0;const $=new Map;let V=[];const U=(e,t=0,r=255)=>Math.max(t,Math.min(r,Number(e)||0)),w=(e,t={})=>self.postMessage({type:e,...t}),re=()=>new Date().toLocaleTimeString("ja-JP",{hour12:!1});function ve(){if(!N||!x)return;const e=new Uint8ClampedArray(x.data);self.postMessage({type:"frame",width:x.width,height:x.height,data:e.buffer},[e.buffer])}function Pe(){ve();const e=++Ae;return w("camera-frame-request",{requestId:e}),new Promise((t,r)=>$.set(e,{resolve:t,reject:r}))}function b(e){return e==null?e:typeof e.toJs=="function"?e.toJs({dict_converter:Object.fromEntries}):ArrayBuffer.isView(e)?Array.from(e):e}function O(e,t=[255,255,255]){const r=b(e);if(typeof r=="number")return[r,r,r,255].map((s,a)=>a===3?255:U(s));const n=Array.isArray(r)?r:t;return[U(n[0]),U(n[1]),U(n[2]),255]}function ue(e){return{width:e.width,height:e.height,data:new Uint8ClampedArray(e.data)}}function ye(e,t,r){t=Math.max(1,Math.floor(t)),r=Math.max(1,Math.floor(r));const n=new Uint8ClampedArray(t*r*4);for(let s=0;s<r;s++){const a=Math.min(e.height-1,Math.floor(s*e.height/r));for(let i=0;i<t;i++){const l=Math.min(e.width-1,Math.floor(i*e.width/t)),o=(a*e.width+l)*4,d=(s*t+i)*4;n[d]=e.data[o],n[d+1]=e.data[o+1],n[d+2]=e.data[o+2],n[d+3]=255}}return{width:t,height:r,data:n}}function se(e,t){const[r,n,s,a]=t.map(Number),i=Math.max(0,Math.floor(r)),l=Math.max(0,Math.floor(n)),o=Math.max(1,Math.min(e.width-i,Math.floor(s))),d=Math.max(1,Math.min(e.height-l,Math.floor(a))),h=new Uint8ClampedArray(o*d*4);for(let f=0;f<d;f++){const m=((l+f)*e.width+i)*4;h.set(e.data.subarray(m,m+o*4),f*o*4)}return{width:o,height:d,data:h}}function Ue(e){if(!z&&!q)return e;const t=new Uint8ClampedArray(e.data.length);for(let r=0;r<e.height;r++)for(let n=0;n<e.width;n++){const s=z?e.width-1-n:n,a=q?e.height-1-r:r;t.set(e.data.subarray((a*e.width+s)*4,(a*e.width+s)*4+4),(r*e.width+n)*4)}return{width:e.width,height:e.height,data:t}}function Ce(e){if(!Q&&!j&&!W)return e;const t=Number(Q)*12,r=1+Number(W)*.12,n=1+Number(j)*.16;for(let s=0;s<e.data.length;s+=4){let a=(e.data[s]-128)*r+128+t,i=(e.data[s+1]-128)*r+128+t,l=(e.data[s+2]-128)*r+128+t;const o=.299*a+.587*i+.114*l;e.data[s]=U(o+(a-o)*n),e.data[s+1]=U(o+(i-o)*n),e.data[s+2]=U(o+(l-o)*n)}return e}function Te(e,t,r){e/=255,t/=255,r/=255,e=e>.04045?((e+.055)/1.055)**2.4:e/12.92,t=t>.04045?((t+.055)/1.055)**2.4:t/12.92,r=r>.04045?((r+.055)/1.055)**2.4:r/12.92;let n=(e*.4124+t*.3576+r*.1805)/.95047,s=e*.2126+t*.7152+r*.0722,a=(e*.0193+t*.1192+r*.9505)/1.08883;const i=l=>l>.008856?Math.cbrt(l):7.787*l+16/116;return n=i(n),s=i(s),a=i(a),[116*s-16,500*(n-s),200*(s-a)]}function ge(e,t,r,n){for(const s of n)if(s.length>=6){const[a,i,l]=Te(e,t,r);if(a>=s[0]&&a<=s[1]&&i>=s[2]&&i<=s[3]&&l>=s[4]&&l<=s[5])return!0}else if(s.length>=2){const a=.299*e+.587*t+.114*r;if(a>=s[0]&&a<=s[1])return!0}return!1}function he(e,t,r,n){if(t=Math.round(t),r=Math.round(r),t<0||r<0||t>=e.width||r>=e.height)return;const s=(r*e.width+t)*4;e.data[s]=n[0],e.data[s+1]=n[1],e.data[s+2]=n[2],e.data[s+3]=255}function C(e,t,r,n,s,a,i=1){t=Math.round(t),r=Math.round(r),n=Math.round(n),s=Math.round(s);const l=Math.abs(n-t),o=t<n?1:-1,d=-Math.abs(s-r),h=r<s?1:-1;let f=l+d;for(;;){const m=Math.max(0,Math.floor(i/2));for(let y=-m;y<=m;y++)for(let F=-m;F<=m;F++)he(e,t+F,r+y,a);if(t===n&&r===s)break;const _=2*f;_>=d&&(f+=d,t+=o),_<=l&&(f+=l,r+=h)}}function Ie(e,t,r,n=1,s=!1){const[a,i,l,o]=t.map(Number);if(s){for(let d=i;d<i+o;d++)for(let h=a;h<a+l;h++)he(e,h,d,r);return}C(e,a,i,a+l,i,r,n),C(e,a,i+o,a+l,i+o,r,n),C(e,a,i,a,i+o,r,n),C(e,a+l,i,a+l,i+o,r,n)}function Oe(e,t,r,n,s,a=1,i=!1){const l=Number(n),o=i?0:Math.max(0,l-a);for(let d=Math.floor(r-l);d<=Math.ceil(r+l);d++)for(let h=Math.floor(t-l);h<=Math.ceil(t+l);h++){const f=Math.hypot(h-t,d-r);f<=l&&f>=o&&he(e,h,d,s)}}function Re(e,t,r,n,s,a=1){if(typeof OffscreenCanvas>"u")return;const l=new OffscreenCanvas(e.width,e.height).getContext("2d");l.putImageData(new ImageData(e.data,e.width,e.height),0,0),l.fillStyle=`rgb(${s[0]},${s[1]},${s[2]})`,l.font=`${Math.max(10,12*Number(a))}px monospace`,l.textBaseline="top",l.fillText(String(n),Number(t),Number(r)),e.data=l.getImageData(0,0,e.width,e.height).data}function _e(e){const t=b(e)||[];return Array.isArray(t)?t.map(r=>Array.from(r,Number)):[]}class ne{constructor(t){this.frame=t,x=t}width(){return this.frame.width}height(){return this.frame.height}size(){return this.frame.data.length}resize(t,r){return this.frame=ye(this.frame,t,r),x=this.frame,this}crop(t){return this.frame=se(this.frame,Array.from(b(t))),x=this.frame,this}copy(t){return t==null?new ne(ue(this.frame)):new ne(se(this.frame,Array.from(b(t))))}binary(t,r=!1){const n=_e(t);for(let s=0;s<this.frame.data.length;s+=4){let a=ge(this.frame.data[s],this.frame.data[s+1],this.frame.data[s+2],n);r&&(a=!a);const i=a?255:0;this.frame.data[s]=i,this.frame.data[s+1]=i,this.frame.data[s+2]=i}return x=this.frame,this}findBlobs(t,r,n=2,s=1,a=!1,i=10,l=10,o=!1,d=0){const h=_e(t),f=r==null?[0,0,this.frame.width,this.frame.height]:Array.from(b(r),Number),m=Math.max(0,f[0]|0),_=Math.max(0,f[1]|0),y=Math.min(this.frame.width,m+(f[2]|0)),F=Math.min(this.frame.height,_+(f[3]|0)),M=y-m,G=F-_,ae=new Uint8Array(M*G),H=new Uint8Array(M*G);for(let g=0;g<G;g++)for(let c=0;c<M;c++){const u=((g+_)*this.frame.width+c+m)*4;let p=ge(this.frame.data[u],this.frame.data[u+1],this.frame.data[u+2],h);a&&(p=!p),ae[g*M+c]=p?1:0}const J=[];for(let g=0;g<G;g+=Math.max(1,Number(s)))for(let c=0;c<M;c+=Math.max(1,Number(n))){const u=g*M+c;if(!ae[u]||H[u])continue;const p=[c],T=[g];H[u]=1;let B=0,k=0,K=c,ie=c,X=g,le=g,ce=0,me=0;for(;B<p.length;){const A=p[B],v=T[B++];k++,ce+=A,me+=v,K=Math.min(K,A),ie=Math.max(ie,A),X=Math.min(X,v),le=Math.max(le,v);for(const[Y,Z]of[[A-1,v],[A+1,v],[A,v-1],[A,v+1]]){if(Y<0||Z<0||Y>=M||Z>=G)continue;const fe=Z*M+Y;ae[fe]&&!H[fe]&&(H[fe]=1,p.push(Y),T.push(Z))}}const oe=ie-K+1,de=le-X+1;k>=Number(l)&&oe*de>=Number(i)&&J.push({x:K+m,y:X+_,w:oe,h:de,pixels:k,cx:Math.round(ce/k)+m,cy:Math.round(me/k)+_,density:k/(oe*de),rotation:0,code:1})}if(o&&J.length>1){const g=[];for(const c of J.sort((u,p)=>p.pixels-u.pixels)){const u=g.find(p=>c.x<=p.x+p.w+d&&c.x+c.w+d>=p.x&&c.y<=p.y+p.h+d&&c.y+c.h+d>=p.y);if(!u)g.push({...c});else{const p=Math.min(u.x,c.x),T=Math.min(u.y,c.y),B=Math.max(u.x+u.w,c.x+c.w),k=Math.max(u.y+u.h,c.y+c.h);u.pixels+=c.pixels,u.x=p,u.y=T,u.w=B-p,u.h=k-T,u.cx=Math.round(p+u.w/2),u.cy=Math.round(T+u.h/2),u.density=u.pixels/(u.w*u.h)}}return g}return J.sort((g,c)=>c.pixels-g.pixels)}drawRectangle(t,r,n=1,s=!1){return Ie(this.frame,Array.from(b(t)),O(r),Number(n),!!s),this}drawLine(t,r,n=1){const s=Array.from(b(t));return C(this.frame,s[0],s[1],s[2],s[3],O(r),Number(n)),this}drawCircle(t,r,n,s,a=1,i=!1){return Oe(this.frame,Number(t),Number(r),Number(n),O(s),Number(a),!!i),this}drawCross(t,r,n,s=5,a=1){const i=O(n);return C(this.frame,t-s,r,t+s,r,i,a),C(this.frame,t,r-s,t,r+s,i,a),this}drawString(t,r,n,s,a=1){return Re(this.frame,t,r,n,O(s),a),this}}function Le(){return{requestCameraFrame:Pe,sensorReset:()=>(I=D.QVGA,P=null,z=!1,q=!1,Q=0,j=0,W=0,te={},!0),setFrameSize:e=>{const t=b(e);I=Array.isArray(t)?t.map(Number):D[String(t)]||D.QVGA},setWindowing:e=>{P=Array.from(b(e),Number)},setHMirror:e=>{z=!!e},setVFlip:e=>{q=!!e},setBrightness:e=>{Q=Number(e)||0},setSaturation:e=>{j=Number(e)||0},setContrast:e=>{W=Number(e)||0},readRegister:e=>Number(te[Number(e)]||0),writeRegister:(e,t)=>{te[Number(e)]=Number(t)&255},snapshot:()=>{let e=Ue(ue(E));if(I&&(e=ye(e,I[0],I[1])),P?.length===2){const[t,r]=P;e=se(e,[(e.width-t)/2,(e.height-r)/2,t,r])}else P?.length>=4&&(e=se(e,P));return e=Ce(e),new ne(e)},imageWidth:e=>e.width(),imageHeight:e=>e.height(),imageSize:e=>e.size(),imageResize:(e,t,r)=>e.resize(t,r),imageCrop:(e,t)=>e.crop(t),imageCopy:(e,t)=>e.copy(t),imageBinary:(e,t,r)=>e.binary(t,r),imageFindBlobs:(e,t,r,n,s,a,i,l,o,d)=>e.findBlobs(t,r,n,s,a,i,l,o,d),drawRectangle:(e,t,r,n,s)=>e.drawRectangle(t,r,n,s),drawLine:(e,t,r,n)=>e.drawLine(t,r,n),drawCircle:(e,t,r,n,s,a,i)=>e.drawCircle(t,r,n,s,a,i),drawCross:(e,t,r,n,s,a)=>e.drawCross(t,r,n,s,a),drawString:(e,t,r,n,s,a)=>e.drawString(t,r,n,s,a),log:(...e)=>{const t=e.map(String).join(" ");V.push(t),V.length>120&&V.shift(),w("log",{level:"stdout",text:t,time:re()})},uartWrite:e=>{const t=b(e),r=typeof t=="string"?new TextEncoder().encode(t):Uint8Array.from(t);return w("log",{level:"uart",text:new TextDecoder().decode(r),bytes:Array.from(r),time:re()}),r.length},uartAny:()=>S.length,uartRead:e=>{const t=e==null||Number(e)<0?S.length:Math.min(Number(e),S.length);return Uint8Array.from(S.splice(0,t))},uartReadline:()=>{const e=S.indexOf(10),t=e<0?S.length:e+1;return t?Uint8Array.from(S.splice(0,t)):null},gpioGet:e=>Number(R[String(e)]||0),gpioSet:(e,t,r="OUT")=>(R[String(e)]=+!!t,w("gpio",{pin:String(e),value:R[String(e)],mode:String(r)}),R[String(e)]),ledSet:(e,t)=>{const r=Math.max(0,Number(e)|0);for(;L.length<=r;)L.push([0,0,0]);L[r]=O(t).slice(0,3)},ledDisplay:()=>w("led",{colors:L}),kpuAvailable:()=>!1,unsupported:e=>{throw new Error(`未対応のAPIです: ${e}`)}}}const Fe=String.raw`
import sys, types, builtins
from js import bridge

class Blob:
    def __init__(self, d): self._d=d
    def x(self): return int(self._d.x)
    def y(self): return int(self._d.y)
    def w(self): return int(self._d.w)
    def h(self): return int(self._d.h)
    def cx(self): return int(self._d.cx)
    def cy(self): return int(self._d.cy)
    def pixels(self): return int(self._d.pixels)
    def rotation(self): return float(self._d.rotation)
    def code(self): return int(self._d.code)
    def density(self): return float(self._d.density)
    def rect(self): return (self.x(),self.y(),self.w(),self.h())
    def __getitem__(self,i): return (self.x(),self.y(),self.w(),self.h(),self.pixels(),self.cx(),self.cy())[i]
    def __repr__(self): return "Blob(x={}, y={}, w={}, h={}, pixels={})".format(self.x(),self.y(),self.w(),self.h(),self.pixels())

class SimImage:
    def __init__(self, handle=None):
        if handle is None: raise RuntimeError('image.Image(path) は未対応です。sensor.snapshot() を使用してください。')
        self._h=handle
    def width(self): return int(bridge.imageWidth(self._h))
    def height(self): return int(bridge.imageHeight(self._h))
    def size(self): return int(bridge.imageSize(self._h))
    def resize(self,w,h): bridge.imageResize(self._h,w,h); return self
    def crop(self,roi): bridge.imageCrop(self._h,roi); return self
    def copy(self,roi=None): return SimImage(bridge.imageCopy(self._h,roi))
    def binary(self,thresholds,invert=False,**kwargs): bridge.imageBinary(self._h,thresholds,invert); return self
    def find_blobs(self,thresholds,roi=None,x_stride=2,y_stride=1,invert=False,area_threshold=10,pixels_threshold=10,merge=False,margin=0,**kwargs):
        result=bridge.imageFindBlobs(self._h,thresholds,roi,x_stride,y_stride,invert,area_threshold,pixels_threshold,merge,margin)
        return [Blob(x) for x in result]
    def draw_rectangle(self,rect,color=(255,255,255),thickness=1,fill=False,**kwargs): bridge.drawRectangle(self._h,rect,color,thickness,fill); return self
    def draw_line(self,line,color=(255,255,255),thickness=1,**kwargs): bridge.drawLine(self._h,line,color,thickness); return self
    def draw_circle(self,x,y,radius,color=(255,255,255),thickness=1,fill=False,**kwargs): bridge.drawCircle(self._h,x,y,radius,color,thickness,fill); return self
    def draw_cross(self,x,y,color=(255,255,255),size=5,thickness=1,**kwargs): bridge.drawCross(self._h,x,y,color,size,thickness); return self
    def draw_string(self,x,y,text,color=(255,255,255),scale=1,**kwargs): bridge.drawString(self._h,x,y,str(text),color,scale); return self

image=types.ModuleType('image'); image.Image=SimImage; sys.modules['image']=image
sensor=types.ModuleType('sensor')
sensor.RGB565='RGB565'; sensor.GRAYSCALE='GRAYSCALE'; sensor.YUV422='YUV422'
for _name in ['QQVGA','QVGA','VGA','QQQVGA','B64X64','B128X128','LCD']: setattr(sensor,_name,_name)
sensor.reset=lambda *a,**k: bridge.sensorReset()
sensor.set_pixformat=lambda *a,**k: None
sensor.set_framesize=lambda value,*a,**k: bridge.setFrameSize(value)
sensor.set_windowing=lambda value,*a,**k: bridge.setWindowing(value)
sensor.set_hmirror=lambda value=True,*a,**k: bridge.setHMirror(value)
sensor.set_vflip=lambda value=True,*a,**k: bridge.setVFlip(value)
sensor.skip_frames=lambda *a,**k: None
sensor.run=lambda *a,**k: None
sensor.set_auto_gain=lambda *a,**k: None
sensor.set_auto_exposure=lambda *a,**k: None
sensor.set_auto_whitebal=lambda *a,**k: None
sensor.set_brightness=lambda value,*a,**k: bridge.setBrightness(value)
sensor.set_saturation=lambda value,*a,**k: bridge.setSaturation(value)
sensor.set_contrast=lambda value,*a,**k: bridge.setContrast(value)
sensor.__read_reg=lambda address: int(bridge.readRegister(address))
sensor.__write_reg=lambda address,value: bridge.writeRegister(address,value)
sensor.snapshot=lambda: SimImage(bridge.snapshot())
async def _snapshot_async():
    await bridge.requestCameraFrame()
    return sensor.snapshot()
sensor.snapshot_async=_snapshot_async
sys.modules['sensor']=sensor

class Clock:
    def __init__(self):
        self._last=_time.time(); self._fps=0
    def tick(self):
        now=_time.time(); delta=now-self._last; self._last=now; self._fps=(1/delta if delta else 0); return delta
    def fps(self): return self._fps
import time as _time
time_mod=types.ModuleType('time')
time_mod.sleep=_time.sleep; time_mod.sleep_ms=lambda ms:_time.sleep(ms/1000); time_mod.ticks_ms=lambda:int(_time.time()*1000); time_mod.clock=Clock
sys.modules['time']=time_mod

class UART:
    UART1=1; UART2=2; UART3=3
    def __init__(self,uart=1,baudrate=115200,*args,**kwargs): self.uart=uart; self.baudrate=baudrate
    def init(self,*args,**kwargs): return None
    def any(self): return int(bridge.uartAny())
    def read(self,n=-1):
        result=bridge.uartRead(n)
        return bytes(result) if result is not None else None
    def readchar(self):
        data=self.read(1); return data[0] if data else -1
    def readline(self):
        result=bridge.uartReadline(); return bytes(result) if result is not None else None
    def write(self,data):
        if isinstance(data,str): data=data.encode('utf-8')
        return int(bridge.uartWrite(list(data)))
    def deinit(self): return None
machine=types.ModuleType('machine'); machine.UART=UART; sys.modules['machine']=machine

class DynamicConstants:
    def __getattr__(self,name): return name
class FM:
    def __init__(self): self.fpioa=DynamicConstants()
    def register(self,*args,**kwargs): return None
    def unregister(self,*args,**kwargs): return None
fm=FM(); fpioa_manager=types.ModuleType('fpioa_manager'); fpioa_manager.fm=fm; sys.modules['fpioa_manager']=fpioa_manager
board=types.ModuleType('board'); board.board_info=DynamicConstants(); sys.modules['board']=board

class GPIO:
    IN=0; OUT=1; PULL_NONE=0; PULL_UP=1; PULL_DOWN=2
    GPIO0='GPIO0'; GPIO1='GPIO1'; GPIO2='GPIO2'; GPIOHS0='GPIOHS0'; GPIOHS1='GPIOHS1'; GPIOHS2='GPIOHS2'
    def __init__(self,pin,mode=OUT,pull=PULL_NONE,value=0,*args,**kwargs):
        self.pin=pin; self.mode=mode
        if mode != self.IN: bridge.gpioSet(str(pin),value,'OUT')
    def value(self,value=None):
        if value is None: return int(bridge.gpioGet(str(self.pin)))
        return int(bridge.gpioSet(str(self.pin),value,'IN' if self.mode==self.IN else 'OUT'))
Maix=types.ModuleType('Maix'); Maix.GPIO=GPIO; sys.modules['Maix']=Maix

class ws2812:
    def __init__(self,pin,led_num=1,*args,**kwargs): self.pin=pin; self.led_num=led_num
    def set_led(self,index,color): bridge.ledSet(index,color)
    def display(self): bridge.ledDisplay()
modules=types.ModuleType('modules'); modules.ws2812=ws2812; sys.modules['modules']=modules

class KPUResult:
    def __init__(self,values): self.values=list(values)
    def __len__(self): return len(self.values)
    def __getitem__(self,i): return self.values[i]
    def tolist(self): return list(self.values)
class Detection:
    def __init__(self,d): self._d=d
    def x(self): return int(self._d.x)
    def y(self): return int(self._d.y)
    def w(self): return int(self._d.w)
    def h(self): return int(self._d.h)
    def value(self): return float(self._d.value)
    def classid(self): return int(self._d.classId)
    def rect(self): return (self.x(),self.y(),self.w(),self.h())
    def __getitem__(self,i): return (self.x(),self.y(),self.w(),self.h(),self.value(),self.classid())[i]
class KPUTask:
    def __init__(self,path): self.path=path
def _require_kpu():
    if not bridge.kpuAvailable(): raise RuntimeError('KPUモデルが読み込まれていません。AIモデル欄でONNXモデルと設定JSONを選択してください。')
kpu=types.ModuleType('KPU')
kpu.load=lambda path,*a,**k: KPUTask(path)
kpu.deinit=lambda task,*a,**k: None
kpu.init_yolo2=lambda *a,**k: _require_kpu()
def _forward(task,img,*args,**kwargs): _require_kpu(); return KPUResult(bridge.kpuValues())
def _run_yolo(task,img,*args,**kwargs): _require_kpu(); return [Detection(d) for d in bridge.kpuDetections()]
kpu.forward=_forward; kpu.run_yolo2=_run_yolo; kpu.softmax=lambda values: KPUResult(values)
sys.modules['KPU']=kpu

_real_print=builtins.print
def sim_print(*args,sep=' ',end='\n',**kwargs): bridge.log(sep.join(str(x) for x in args)+end.rstrip('\n'))
builtins.print=sim_print
`;async function Ge(){if(ee)return ee;w("status",{phase:"loading-python",text:"Python環境を読み込んでいます"});const{loadPyodide:e}=await import(new URL("/pyodide/pyodide.mjs",self.location.href).href);return ee=await e({indexURL:new URL("/pyodide/",self.location.href).href}),ee}self.onmessage=async e=>{const t=e.data;if(t?.type==="camera-frame"){const n=$.get(t.requestId);if(!n)return;$.delete(t.requestId),E={width:t.image.width,height:t.image.height,data:new Uint8ClampedArray(t.image.data)},n.resolve(!0);return}if(t?.type==="camera-frame-error"){const n=$.get(t.requestId);if(!n)return;$.delete(t.requestId),n.reject(new Error(t.message||"カメラフレームを取得できませんでした。"));return}if(t?.type!=="run")return;let r=[];try{V=[],N=!!t.cameraMode,E={width:t.image.width,height:t.image.height,data:new Uint8ClampedArray(t.image.data)},x=ue(E),I=D.QVGA,P=null,z=!1,q=!1,Q=0,j=0,W=0,te={},S=Array.from(new Uint8Array(t.uart||new ArrayBuffer(0))),R={...t.gpio||{}},L=[[0,0,0],[0,0,0],[0,0,0],[0,0,0]],Ne=null;const n=await Ge();self.bridge=Le(),n.globals.set("bridge",self.bridge),await n.runPythonAsync(Fe);const s=`/unitv-project-${crypto.randomUUID()}`;n.FS.mkdirTree(s);for(const h of t.files||[]){const f=String(h.name||"").replace(/\\/g,"/").replace(/^\/+/,"");if(!f.endsWith(".py")||f.split("/").some(y=>!y||y==="."||y===".."))continue;const m=f.includes("/")?f.slice(0,f.lastIndexOf("/")):"";m&&n.FS.mkdirTree(`${s}/${m}`),n.FS.writeFile(`${s}/${f}`,String(h.code||""),{encoding:"utf8"});const _=f.replace(/\.py$/,"").replace(/\//g,".").replace(/\.__init__$/,"");await n.runPythonAsync(`import sys
sys.modules.pop(${JSON.stringify(_)}, None)`)}const a=String(t.filename||"").replace(/\\/g,"/").includes("/")?String(t.filename).replace(/\\/g,"/").slice(0,String(t.filename).replace(/\\/g,"/").lastIndexOf("/")):"";await n.runPythonAsync(`import os, sys, importlib
os.chdir(${JSON.stringify(s)})
sys.path.insert(0, ${JSON.stringify(s)})
sys.path.insert(0, ${JSON.stringify(`${s}/${a}`)})
importlib.invalidate_caches()`),w("status",{phase:"executing",text:N?"カメラフレームを連続処理しています":"コードを実行しています",liveCamera:N});const{prepared:i,limited:l,mappings:o}=ke(t.code,N);r=o,l&&w("log",{level:"system",text:"固定画像モードのため while(True) を1フレームだけ実行します。",time:re()}),N&&w("log",{level:"system",text:"カメラモード: while(True) を維持し、sensor.snapshot() ごとに新しいフレームを取得します。停止ボタンで終了できます。",time:re()}),await n.runPythonAsync(i,{filename:t.filename||"main.py"});const d=x||E;N=!1,w("result",{width:d.width,height:d.height,data:d.data.buffer,gpio:R,leds:L},[d.data.buffer])}catch(n){N=!1;const s=String(n?.message||n),a=String(n?.stack||""),i=V.join(`
`),l=i.includes("Traceback")?i:s==="PythonError"&&a?a:s;let o=Me(l,a);o.filename===String(t.filename||"").replace(/\\/g,"/")&&(o=Se(o,r)),w("error",{message:`${o.type}: ${o.reason}`,stack:a,error:o})}};
